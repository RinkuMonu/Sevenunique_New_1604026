<?php $__env->startSection('title', 'Home - High Court of Rajasthan'); ?>

<?php $__env->startSection('content'); ?>

<style>
/* CSS styles to maintain interface aesthetics */
.v1-media-judgments-section .nav-pills .nav-link {
    color: #6c757d;
    background: transparent;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}
.v1-media-judgments-section .nav-pills .nav-link.active {
    color: #ffffff !important;
    background-color: #1b431c !important; /* Custom theme Green */
}
.v1-media-judgments-section .animate-pulse {
    animation: pulse-red 2s infinite;
}
@keyframes pulse-red {
    0% { transform: scale(0.95); opacity: 0.7; }
    50% { transform: scale(1.05); opacity: 1; }
    100% { transform: scale(0.95); opacity: 0.7; }
}
.v1-media-judgments-section .start-border-primary {
    border-left: 4px solid #1b431c !important; /* Dynamic indicator line */
}
.v1-media-judgments-section .text-truncate-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.v1-media-judgments-section .hover-underline:hover {
    text-decoration: underline !important;
    color: #1b431c !important;
}
</style>


<div class="modal fade" id="urnNotificationModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="urnNotificationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;">
            <div class="modal-header text-white px-4 py-3 border-0 position-relative" style="background-color: #1b431c;">
                <div class="d-flex align-items-center gap-2">
                    <i class="fas fa-circle-info fs-4 text-warning"></i>
                    <h5 class="modal-title fw-bold" id="urnNotificationModalLabel" style="font-family: 'Playfair Display', serif; letter-spacing: 0.5px;">
                        Important Notice: Uniform Registration Number (URN)
                    </h5>
                </div>
                <button type="button" class="btn-close btn-close-white position-absolute end-0 me-3" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body p-4 bg-light">
                <div class="bg-white p-4 rounded-3 border shadow-sm mb-3">
                    <p class="lh-lg text-secondary mb-3">
                        It is notified to all concerned that the Rajasthan High Court has implemented <strong>Uniform Registration Number (URN)</strong> System for all cases at Jodhpur and Jaipur Bench. Every case will now also have a single unified number, besides earlier prevalent practice of Case Registration Number and CNR. URN will assist in easier tracking and smooth access to case status independent of establishment type.
                    </p>
                    <p class="lh-lg text-secondary mb-0">
                        Advocates and litigants are requested to use the newly introduced facility of URN. Feedback/suggestions may kindly be shared on official Mail ID - 
                        <a href="mailto:cpc-raj@aij.gov.in" class="text-decoration-none fw-semibold" style="color: #1b431c;">cpc-raj@aij.gov.in</a>.
                    </p>
                </div>
                
                <div class="d-flex justify-content-start align-items-center">
                    <a href="#" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-2 rounded-2 px-3 py-2 fw-medium">
                        <i class="fas fa-question-circle text-muted"></i>
                        <span>Click here for FAQs on Uniform Case Registration Number (URN)</span>
                        <i class="fas fa-external-link-alt ms-1 text-muted" style="font-size: 0.75rem;"></i>
                    </a>
                </div>
            </div>
            
            <div class="modal-footer border-0 bg-light px-4 pb-4 pt-0 justify-content-end">
                <button type="button" class="btn btn-secondary px-4 py-2 fw-medium rounded-2" data-bs-dismiss="modal" style="font-size: 0.9rem;">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>


<section class="v1-hero position-relative overflow-hidden">
    <div id="heroBackgroundCarousel" class="carousel slide carousel-fade position-absolute top-0 start-0 w-100 h-100 z-1" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-inner h-100">
            <div class="carousel-item active h-100">
                <div class="v1-hero-bg-slide" style="background-image: url('<?php echo e(asset('assets/hero/image.jpg')); ?>');"></div>
            </div>
            <div class="carousel-item h-100">
                <div class="v1-hero-bg-slide" style="background-image: url('<?php echo e(asset('assets/hero/image4.jpg')); ?>');"></div>
            </div>
            <div class="carousel-item h-100">
                <div class="v1-hero-bg-slide" style="background-image: url('<?php echo e(asset('assets/hero/image5.jpg')); ?>');"></div>
            </div>
        </div>
    </div>

    <div class="container-fluid px-4 position-relative z-2">
        <div class="row align-items-center min-vh-60">
            <div class="col-lg-7 py-5">
                <span class="v1-hero-badge ">Established 1949</span>
                <h2 class="v1-hero-title">Justice. Integrity.<br>Excellence.</h2>
                <p class="v1-hero-subtitle">The High Court of Rajasthan stands as a beacon of constitutional justice, serving millions across the state with transparency and efficiency.</p>
            </div>
        </div>
    </div>
</section>


<section class="v1-services-bar my-5">
    <div class="container">
        <div class="row g-4">
            <?php
            $services = [
                ['icon' => 'fa-gavel', 'title' => 'Case Status', 'color' => 'sage', 'has_popup' => true, 'id' => 'svc-case-status'],
                ['icon' => 'fa-calendar-alt', 'title' => 'Cause List', 'color' => 'terracotta', 'has_popup' => true, 'id' => 'svc-cause-list'],
                ['icon' => 'fa-file-invoice', 'title' => 'e-True Copy', 'color' => 'amber', 'has_popup' => true, 'id' => 'svc-true-copy'],
                ['icon' => 'fa-laptop-code', 'title' => 'e-Services', 'color' => 'slate', 'has_popup' => true, 'id' => 'svc-e-services'],
                ['icon' => 'fa-balance-scale', 'title' => 'Judgments', 'color' => 'rust', 'has_popup' => false, 'link' => '#'],
                ['icon' => 'fa-upload', 'title' => 'e-Filing', 'color' => 'forest', 'has_popup' => false, 'link' => '#'],
                ['icon' => 'fa-hands-helping', 'title' => 'Legal Aid', 'color' => 'navy', 'has_popup' => false, 'link' => '#'],
                ['icon' => 'fa-circle-info', 'title' => 'RTI Portal', 'color' => 'gold', 'has_popup' => false, 'link' => '#'],
            ];
            ?>

            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-12 position-relative <?php echo e($svc['has_popup'] ? 'svc-dropdown-wrapper' : ''); ?>">
                <a href="<?php echo e($svc['link'] ?? '#'); ?>" class="v1-service-wide-card d-flex align-items-center v1-svc-<?php echo e($svc['color']); ?>">
                    <div class="v1-svc-icon-box me-3">
                        <i class="fas <?php echo e($svc['icon']); ?>"></i>
                    </div>
                    <h5 class="v1-svc-title-text mb-0"><?php echo e($svc['title']); ?></h5>
                </a>

                <?php if($svc['has_popup']): ?>
                    <ul class="dropdown-menu card-transparent-popup">
                        <?php if($svc['id'] == 'svc-case-status'): ?>
                            <li><a class="dropdown-item" href="#">Search by Case Number</a></li>
                            <li><a class="dropdown-item" href="#">Search by Party Name</a></li>
                            <li><a class="dropdown-item" href="#">Search by Advocate Name</a></li>
                            <li><a class="dropdown-item" href="#">Filing Status Inquiry</a></li>
                        <?php elseif($svc['id'] == 'svc-cause-list'): ?>
                            <li><a class="dropdown-item" href="#">Daily Cause List</a></li>
                            <li><a class="dropdown-item" href="#">Weekly Cause List</a></li>
                            <li><a class="dropdown-item" href="#">Main Seat Jodhpur</a></li>
                            <li><a class="dropdown-item" href="#">Jaipur Bench List</a></li>
                        <?php elseif($svc['id'] == 'svc-true-copy'): ?>
                            <li><a class="dropdown-item" href="#">Apply for Certified Copy</a></li>
                            <li><a class="dropdown-item" href="#">Track Application Status</a></li>
                            <li><a class="dropdown-item" href="#">Fee Structure Details</a></li>
                            <li><a class="dropdown-item" href="#">Online Payment Portal</a></li>
                        <?php elseif($svc['id'] == 'svc-e-services'): ?>
                            <li><a class="dropdown-item" href="#">Online e-Filing Portal</a></li>
                            <li><a class="dropdown-item" href="#">Virtual Justice Clock</a></li>
                            <li><a class="dropdown-item" href="#">Digital Display Board</a></li>
                            <li><a class="dropdown-item" href="#">Sulah Mediation Bot</a></li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="v1-stats-ticker-wrapper">
    <div class="v1-stats-bar-slim py-3">
        <div class="container">
            <div class="row align-items-center justify-content-center text-center g-3">
                <?php
                $stats = [
                    ['number' => '75+', 'label' => 'Years of Service', 'icon' => 'fa-building-columns'],
                    ['number' => '2', 'label' => 'Benches (Jodhpur & Jaipur)', 'icon' => 'fa-gavel'],
                    ['number' => '46', 'label' => 'Sitting Judges', 'icon' => 'fa-user-tie'],
                    ['number' => '12L+', 'label' => 'Cases Disposed', 'icon' => 'fa-square-check'],
                ];
                ?>
                <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-3 border-end-custom">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <i class="fas <?php echo e($stat['icon']); ?> text-gold opacity-75 small"></i>
                        <span class="v1-stat-number fw-bold text-white"><?php echo e($stat['number']); ?></span>
                        <span class="v1-stat-label text-white-50 small"><?php echo e($stat['label']); ?></span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="v1-news-channel-ticker py-2">
        <div class="container-fluid px-0 d-flex align-items-center">
            <div class="ticker-header px-4 fw-bold text-uppercase position-relative z-3">
                <i class="fas fa-bullhorn me-1 text-warning"></i> Notifications
            </div>
            <div class="ticker-scroll-container position-relative overflow-hidden flex-grow-1">
                <div class="ticker-scroll-track">
                    <a href="#" class="ticker-item"><span>1.</span> Notification regarding winter vacation roster arrangements.</a>
                    <a href="#" class="ticker-item"><span>2.</span> Certified copy application link activated for lower district courts.</a>
                    <a href="#" class="ticker-item"><span>3.</span> Live streaming link for Court Room No. 4 principal seat.</a>
                    <a href="#" class="ticker-item"><span>4.</span> Recruitment results for Junior Judicial Assistant examination 2026.</a>
                    <a href="#" class="ticker-item"><span>5.</span> Digital e-filing helpdesk setup guidelines for advocates.</a>
                    <a href="#" class="ticker-item"><span>6.</span> Dynamic sitting structure update of Jodhpur main assembly.</a>
                    <a href="#" class="ticker-item"><span>7.</span> Amended mediation rules booklet released by high authority committee.</a>
                    <a href="#" class="ticker-item"><span>8.</span> Standard Operating Procedure (SOP) regarding physical filings.</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="v1-media-judgments-section py-5 bg-white">
    <div class="container-fluid px-4">
        <div class="row g-4">
            
            
            <div class="col-lg-6">
                <div class="v1-panel h-100 border rounded-3 p-4 shadow-sm bg-light">
                    <div class="v1-panel-header d-flex align-items-center justify-content-between mb-4 border-bottom pb-2">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-video text-danger animate-pulse"></i>
                            <h4 class="fw-bold text-dark mb-0" style="font-family: 'Playfair Display', serif;">Republic Day Celebration</h4>
                        </div>
                    </div>
                    
                    <div class="ratio ratio-16x9 rounded-3 overflow-hidden shadow-sm border mb-3">
                    <iframe 
                        src="https://www.youtube.com/embed/xlxzatKJvn4"
                        title="YouTube video player"
                        allowfullscreen>
                    </iframe>
                </div>
                                    
                    <!-- <div class="d-flex justify-content-between align-items-center px-1">
                        <a href="#" class="text-decoration-none small text-secondary fw-semibold hover-underline">
                            <i class="fas fa-broadcast-tower me-1 text-primary"></i> Live Sessions
                        </a>
                        <a href="#" class="text-decoration-none small text-secondary fw-semibold hover-underline">
                            <i class="fas fa-history me-1 text-muted"></i> Previous Sessions
                        </a>
                    </div> -->
                </div>
            </div>

            
            <div class="col-lg-6">
                <div class="v1-panel h-100 border rounded-3 p-4 shadow-sm bg-light">
                    <div class="v1-panel-header d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4 border-bottom pb-2">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-gavel text-success"></i>
                            <h4 class="fw-bold text-dark mb-0" style="font-family: 'Playfair Display', serif;">Latest Judgments</h4>
                        </div>
                        
                        <ul class="nav nav-pills bg-white p-1 rounded-2 border shadow-sm" id="judgmentBenchTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active px-3 py-1 fw-medium" id="jodhpur-tab" data-bs-toggle="pill" data-bs-target="#jodhpur-judgments" type="button" role="tab" aria-controls="jodhpur-judgments" aria-selected="true" style="font-size: 0.85rem;">
                                    Jodhpur Main Seat
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link px-3 py-1 fw-medium" id="jaipur-tab" data-bs-toggle="pill" data-bs-target="#jaipur-judgments" type="button" role="tab" aria-controls="jaipur-judgments" aria-selected="false" style="font-size: 0.85rem;">
                                    Jaipur Bench
                                </button>
                            </li>
                        </ul>
                    </div>

                    <div class="tab-content" id="judgmentBenchTabsContent">
                        
                        <div class="tab-pane fade show active" id="jodhpur-judgments" role="tabpanel" aria-labelledby="jodhpur-tab">
                            <div class="d-flex flex-column gap-3">
                                <div class="p-3 bg-white border start-border-primary rounded-3 shadow-sm position-relative">
                                    <span class="badge bg-success-subtle text-success border border-success-subtle mb-2 px-2 py-1 rounded-1" style="font-size: 0.75rem;">Civil Case</span>
                                    <h6 class="fw-bold mb-1 text-dark">Suomoto v. State of Rajasthan & Ors.</h6>
                                    <p class="text-secondary mb-0 small text-truncate-2">Judgment regarding guidelines for urban infrastructure development plans at Jodhpur region division.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3">
                                        <span><i class="far fa-calendar-alt me-1"></i> 21.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 4.2 MB</span>
                                    </div>
                                </div>

                                <div class="p-3 bg-white border start-border-primary rounded-3 shadow-sm position-relative">
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle mb-2 px-2 py-1 rounded-1" style="font-size: 0.75rem;">Criminal Appeal</span>
                                    <h6 class="fw-bold mb-1 text-dark">Ramesh Kumar v. State of Rajasthan</h6>
                                    <p class="text-secondary mb-0 small text-truncate-2">Detailed parameters for grant of regular suspension of sentence under updated security acts.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3">
                                        <span><i class="far fa-calendar-alt me-1"></i> 20.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 1.8 MB</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="jaipur-judgments" role="tabpanel" aria-labelledby="jaipur-tab">
                            <div class="d-flex flex-column gap-3">
                                <div class="p-3 bg-white border start-border-primary rounded-3 shadow-sm position-relative">
                                    <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle mb-2 px-2 py-1 rounded-1" style="font-size: 0.75rem;">Writ Petition</span>
                                    <h6 class="fw-bold mb-1 text-dark">Mahendra Singh v. Technical Education Dept.</h6>
                                    <p class="text-secondary mb-0 small text-truncate-2">Interim operational structure orders regulating institutional affiliations and quota rosters within Jaipur division.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3">
                                        <span><i class="far fa-calendar-alt me-1"></i> 21.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 2.9 MB</span>
                                    </div>
                                </div>

                                <div class="p-3 bg-white border start-border-primary rounded-3 shadow-sm position-relative">
                                    <span class="badge bg-success-subtle text-success border border-success-subtle mb-2 px-2 py-1 rounded-1" style="font-size: 0.75rem;">Service Matter</span>
                                    <h6 class="fw-bold mb-1 text-dark">Smt. Anjali Sharma v. State Personnel Dept.</h6>
                                    <p class="text-secondary mb-0 small text-truncate-2">Adjudication over selection seniority structures and administrative reservation protocols under state rules.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3">
                                        <span><i class="far fa-calendar-alt me-1"></i> 19.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 3.5 MB</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="text-start mt-4">
                        <a href="#" class="btn btn-sm btn-outline-secondary px-4 py-2 fw-medium rounded-2" style="font-size: 0.85rem;">
                            View All Judgments <i class="fas fa-arrow-right ms-1 text-muted" style="font-size: 0.75rem;"></i>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>



<section class="v1-gallery py-5">
    <div class="container-fluid px-4">
        <div class="v1-section-header text-center mb-4">
            <span class="v1-section-tag">Gallery</span>
            <h3>Photo Gallery</h3>
        </div>
        <div class="row g-3">
            <div class="col-lg-6">
                <div class="v1-gallery-main">
                    <img src="https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=700&h=400&fit=crop" alt="Court Building" class="img-fluid w-100">
                    <div class="v1-gallery-overlay">High Court of Rajasthan – Jodhpur</div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row g-3">
                    <?php
                    $gImages = [
                        'https://images.unsplash.com/photo-1575505586569-646b2ca898fc?w=350&h=193&fit=crop',
                        'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=350&h=193&fit=crop',
                        'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=350&h=193&fit=crop',
                        'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?w=350&h=193&fit=crop',
                    ];
                    ?>
                    <?php $__currentLoopData = $gImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6">
                        <div class="v1-gallery-thumb">
                            <img src="<?php echo e($img); ?>" alt="Gallery" class="img-fluid w-100">
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Main Font Size Function
function changeFontSize(dir) {
    const root = document.documentElement;
    const current = parseFloat(getComputedStyle(root).fontSize);
    if (dir === 0) root.style.fontSize = '16px';
    else root.style.fontSize = Math.max(12, Math.min(22, current + dir * 2)) + 'px';
}

// Session-based First-Time Only Trigger for URN Modal Popup
document.addEventListener("DOMContentLoaded", function () {
    // Check local session storage if modal was shown during current session
    if (!sessionStorage.getItem("urnModalShown")) {
        // Initialize and fire standard Bootstrap 5 Modal instantiation
        const modalElement = document.getElementById('urnNotificationModal');
        const bootstrapModal = new bootstrap.Modal(modalElement);
        
        // Short timeout sequence for visual enhancement
        setTimeout(() => {
            bootstrapModal.show();
            // Set session key flags so it won't show again on internal redirects or refreshing
            sessionStorage.setItem("urnModalShown", "true");
        }, 1200);
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main-v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/pages/home-v1.blade.php ENDPATH**/ ?>