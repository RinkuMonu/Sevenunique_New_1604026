<?php $__env->startSection('title', 'Home - High Court of Rajasthan'); ?>

<?php $__env->startSection('content'); ?>


<div class="v2-ticker">
    <div class="container-xl">
        <div class="d-flex align-items-center">
            <span class="v2-ticker-label"><i class="fas fa-bell me-2"></i>Latest</span>
            <div class="v2-ticker-text">
                <marquee behavior="scroll" direction="left" scrollamount="4">
                    High Court is closed on 25th December 2024 on account of Christmas &nbsp;|&nbsp;
                    e-Filing portal updated with new features for urgent petitions &nbsp;|&nbsp;
                    National Lok Adalat scheduled for 14th December 2024 &nbsp;|&nbsp;
                    Applications invited for Civil Judge (Junior Division) Recruitment 2024 &nbsp;|&nbsp;
                    Winter Vacation: 25th Dec 2024 – 3rd Jan 2025
                </marquee>
            </div>
        </div>
    </div>
</div>


<section class="v2-hero">
    <div class="container-xl">
        <div class="row align-items-center py-5">
            <div class="col-lg-8">
                <nav aria-label="breadcrumb" class="v2-breadcrumb mb-3">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item active">Home</li>
                    </ol>
                </nav>
                <h2 class="v2-hero-heading">High Court of Rajasthan</h2>
                <p class="v2-hero-sub">Serving constitutional justice to the people of Rajasthan since 1949. The court exercises extraordinary original civil jurisdiction and acts as the appellate authority for all districts of the state.</p>
                <div class="d-flex flex-wrap gap-3 mt-4">
                    <a href="#" class="v2-cta-primary">Search Judgments</a>
                    <a href="#" class="v2-cta-outline">Case Status (CNR)</a>
                    <a href="#" class="v2-cta-outline">Today's Cause List</a>
                </div>
            </div>
            <div class="col-lg-4 d-none d-lg-block text-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/160px-Emblem_of_India.svg.png" alt="National Emblem" class="v2-hero-emblem">
                <p class="v2-hero-motto mt-3">सत्यमेव जयते</p>
            </div>
        </div>
    </div>
</section>


<section class="v2-quick-services py-4">
    <div class="container-xl">
        <div class="row g-3">
            <?php
            $qsvc = [
                ['icon' => 'fa-search', 'title' => 'Case Status', 'sub' => 'CNR / Party Name', 'link' => '#'],
                ['icon' => 'fa-list-alt', 'title' => 'Cause List', 'sub' => 'Daily Hearing List', 'link' => '#'],
                ['icon' => 'fa-file-signature', 'title' => 'e-Filing', 'sub' => 'File Petition Online', 'link' => '#'],
                ['icon' => 'fa-balance-scale-right', 'title' => 'Judgments', 'sub' => 'Search Orders', 'link' => '#'],
                ['icon' => 'fa-hand-holding-heart', 'title' => 'Legal Aid', 'sub' => 'Free Assistance', 'link' => '#'],
                ['icon' => 'fa-briefcase', 'title' => 'Recruitment', 'sub' => 'Current Openings', 'link' => '#'],
            ];
            ?>
            <?php $__currentLoopData = $qsvc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-md-4 col-6">
                <a href="<?php echo e($s['link']); ?>" class="v2-qsvc-card">
                    <div class="v2-qsvc-icon"><i class="fas <?php echo e($s['icon']); ?>"></i></div>
                    <div class="v2-qsvc-title"><?php echo e($s['title']); ?></div>
                    <div class="v2-qsvc-sub"><?php echo e($s['sub']); ?></div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="v2-main-content py-4">
    <div class="container-xl">
        <div class="row g-4">

            
            <div class="col-lg-8">

                
                <div class="v2-content-box mb-4">
                    <div class="v2-box-header">
                        <h5><i class="fas fa-clipboard-list me-2"></i>Notices & Circulars</h5>
                        <a href="#" class="v2-view-more">View All <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="v2-notice-table">
                        <table class="table table-hover mb-0">
                            <thead class="v2-table-head">
                                <tr>
                                    <th>Date</th>
                                    <th>Subject</th>
                                    <th>Type</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $notices = [
                                    ['date' => '18-12-2024', 'subject' => 'Circular regarding e-filing protocol for urgent matters — Jaipur Bench', 'type' => 'Circular', 'new' => true],
                                    ['date' => '15-12-2024', 'subject' => 'Administrative notification for winter vacation schedule 2024–25', 'type' => 'Notification', 'new' => true],
                                    ['date' => '12-12-2024', 'subject' => 'Guidelines for submission of Annual Property Returns by Judicial Officers', 'type' => 'Circular', 'new' => false],
                                    ['date' => '10-12-2024', 'subject' => 'Video conferencing facility protocol for district courts and subordinate courts', 'type' => 'Circular', 'new' => false],
                                    ['date' => '05-12-2024', 'subject' => 'Mediation Centre appointment procedures updated guidelines', 'type' => 'Notice', 'new' => false],
                                    ['date' => '01-12-2024', 'subject' => 'Recruitment notification for Civil Judge (Junior Division) 2024–25', 'type' => 'Recruitment', 'new' => false],
                                ];
                                ?>
                                <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="v2-date-cell text-nowrap"><?php echo e($n['date']); ?></td>
                                    <td>
                                        <a href="#" class="v2-subject-link">
                                            <?php echo e($n['subject']); ?>

                                            <?php if($n['new']): ?><span class="v2-new-badge">New</span><?php endif; ?>
                                        </a>
                                    </td>
                                    <td><span class="v2-type-badge v2-type-<?php echo e(strtolower($n['type'])); ?>"><?php echo e($n['type']); ?></span></td>
                                    <td><a href="#" class="v2-pdf-link"><i class="fas fa-file-pdf"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                
                <div class="v2-content-box mb-4">
                    <div class="v2-box-header">
                        <h5><i class="fas fa-gavel me-2"></i>Recent Judgments</h5>
                        <a href="#" class="v2-view-more">Search All <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="v2-judgment-list">
                        <?php
                        $judgments = [
                            ['case' => 'D.B. Civil Writ Petition No. 12345/2024', 'parties' => 'Ramesh Kumar vs State of Rajasthan & Ors.', 'date' => '17 Dec 2024', 'bench' => 'Division Bench'],
                            ['case' => 'S.B. Civil First Appeal No. 8756/2023', 'parties' => 'M/s ABC Trading Co. vs M/s XYZ Enterprises', 'date' => '16 Dec 2024', 'bench' => 'Single Bench'],
                            ['case' => 'D.B. Criminal Appeal No. 4532/2024', 'parties' => 'State of Rajasthan vs Mohan Lal & Ors.', 'date' => '14 Dec 2024', 'bench' => 'Division Bench'],
                            ['case' => 'S.B. Civil Writ Petition No. 19832/2024', 'parties' => 'Suresh Sharma vs Commissioner, Jaipur Municipal Corporation', 'date' => '13 Dec 2024', 'bench' => 'Single Bench'],
                        ];
                        ?>
                        <?php $__currentLoopData = $judgments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="v2-judgment-item">
                            <div class="v2-judgment-meta d-flex gap-3 mb-1">
                                <span class="v2-case-number"><i class="fas fa-hashtag me-1"></i><?php echo e($j['case']); ?></span>
                                <span class="v2-bench-tag"><?php echo e($j['bench']); ?></span>
                            </div>
                            <div class="v2-judgment-parties"><?php echo e($j['parties']); ?></div>
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <span class="v2-judgment-date"><i class="far fa-calendar me-1"></i><?php echo e($j['date']); ?></span>
                                <a href="#" class="v2-download-link"><i class="fas fa-download me-1"></i>Download PDF</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div class="v2-content-box">
                    <div class="v2-box-header">
                        <h5><i class="fas fa-newspaper me-2"></i>Court News</h5>
                        <a href="#" class="v2-view-more">All News <i class="fas fa-chevron-right"></i></a>
                    </div>
                    <div class="row g-3 p-3">
                        <?php
                        $cnews = [
                            ['img' => 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=300&h=180&fit=crop', 'date' => '18 Dec 2024', 'title' => 'Chief Justice inaugurates new digital court complex at Jodhpur Principal Seat', 'excerpt' => 'The state-of-the-art facility includes 24 court rooms equipped with e-court technology.'],
                            ['img' => 'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=300&h=180&fit=crop', 'date' => '15 Dec 2024', 'title' => 'Mega Lok Adalat settles over 50,000 pending cases across Rajasthan districts', 'excerpt' => 'The SLSA organized state-wide Lok Adalat with participation from all district courts.'],
                            ['img' => 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=300&h=180&fit=crop', 'date' => '12 Dec 2024', 'title' => 'Workshop on mediation and ADR for advocates conducted at Jaipur Bench', 'excerpt' => 'Over 200 advocates participated in the two-day intensive mediation training programme.'],
                        ];
                        ?>
                        <?php $__currentLoopData = $cnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="v2-news-card">
                                <img src="<?php echo e($cn['img']); ?>" alt="News" class="v2-news-img">
                                <div class="v2-news-body">
                                    <span class="v2-news-date"><?php echo e($cn['date']); ?></span>
                                    <a href="#" class="v2-news-title"><?php echo e($cn['title']); ?></a>
                                    <p class="v2-news-excerpt"><?php echo e($cn['excerpt']); ?></p>
                                    <a href="#" class="v2-read-more">Read more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4">

                
                <div class="v2-sidebar-box v2-search-box-widget mb-4">
                    <h6 class="v2-sidebar-title"><i class="fas fa-search me-2"></i>Quick Case Search</h6>
                    <div class="mb-3">
                        <label class="v2-form-label">Search By</label>
                        <select class="form-select v2-form-select">
                            <option>CNR Number</option>
                            <option>Case Number</option>
                            <option>Party Name</option>
                            <option>FIR Number</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="v2-form-label">Bench</label>
                        <select class="form-select v2-form-select">
                            <option>Jodhpur (Principal Seat)</option>
                            <option>Jaipur Bench</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control v2-form-input" placeholder="Enter CNR / Case Number / Name">
                    </div>
                    <button class="v2-search-btn w-100"><i class="fas fa-search me-2"></i>Search Case</button>
                </div>

                
                <div class="v2-sidebar-box mb-4">
                    <h6 class="v2-sidebar-title"><i class="fas fa-calendar-day me-2"></i>Today's Cause List</h6>
                    <div class="v2-causelist-widget">
                        <?php
                        $benches = [
                            ['id' => 'DB-I', 'title' => 'Division Bench I', 'judge' => 'CJ + J. Sharma', 'count' => 42],
                            ['id' => 'DB-II', 'title' => 'Division Bench II', 'judge' => 'J. Gupta + J. Verma', 'count' => 38],
                            ['id' => 'SB-I', 'title' => 'Single Bench I', 'judge' => 'J. Mathur', 'count' => 65],
                            ['id' => 'SB-II', 'title' => 'Single Bench II', 'judge' => 'J. Trivedi', 'count' => 71],
                            ['id' => 'SB-III', 'title' => 'Single Bench III', 'judge' => 'J. Mehta', 'count' => 58],
                        ];
                        ?>
                        <?php $__currentLoopData = $benches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="v2-bench-row">
                            <div>
                                <div class="v2-bench-id"><?php echo e($b['id']); ?></div>
                                <div class="v2-bench-judge"><?php echo e($b['judge']); ?></div>
                            </div>
                            <div class="v2-bench-count"><?php echo e($b['count']); ?></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a href="#" class="v2-full-causelist-btn mt-3 d-block text-center">Download Full Cause List <i class="fas fa-download ms-1"></i></a>
                </div>

                
                <div class="v2-sidebar-box mb-4">
                    <h6 class="v2-sidebar-title"><i class="fas fa-link me-2"></i>Important Portals</h6>
                    <ul class="v2-imp-links">
                        <li><a href="#"><i class="fas fa-external-link-alt"></i>eCourts Services Portal</a></li>
                        <li><a href="#"><i class="fas fa-external-link-alt"></i>National Judicial Data Grid</a></li>
                        <li><a href="#"><i class="fas fa-external-link-alt"></i>Supreme Court of India</a></li>
                        <li><a href="#"><i class="fas fa-external-link-alt"></i>NALSA Legal Aid</a></li>
                        <li><a href="#"><i class="fas fa-external-link-alt"></i>Virtual Court Portal</a></li>
                        <li><a href="#"><i class="fas fa-external-link-alt"></i>Department of Justice</a></li>
                        <li><a href="#"><i class="fas fa-external-link-alt"></i>High Court Bar Association</a></li>
                    </ul>
                </div>

                
                <div class="v2-sidebar-box">
                    <h6 class="v2-sidebar-title"><i class="fas fa-calendar-alt me-2"></i>Upcoming Events</h6>
                    <?php
                    $events = [
                        ['month' => 'JAN', 'day' => '14', 'title' => 'National Lok Adalat', 'loc' => 'All Districts'],
                        ['month' => 'JAN', 'day' => '20', 'title' => 'Judicial Conference 2025', 'loc' => 'Jodhpur'],
                        ['month' => 'FEB', 'day' => '01', 'title' => 'Legal Aid Camp', 'loc' => 'Jaipur Bench'],
                        ['month' => 'FEB', 'day' => '15', 'title' => 'Mediation Day', 'loc' => 'State-wide'],
                    ];
                    ?>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="v2-event-row">
                        <div class="v2-event-cal">
                            <span class="v2-ev-month"><?php echo e($ev['month']); ?></span>
                            <span class="v2-ev-day"><?php echo e($ev['day']); ?></span>
                        </div>
                        <div>
                            <div class="v2-ev-title"><?php echo e($ev['title']); ?></div>
                            <div class="v2-ev-loc"><i class="fas fa-map-pin me-1"></i><?php echo e($ev['loc']); ?></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div>
</section>


<section class="v2-stats-band py-4">
    <div class="container-xl">
        <div class="row text-center g-0">
            <?php
            $stats = [
                ['n' => '75+', 'l' => 'Years of Service'],
                ['n' => '2', 'l' => 'Court Benches'],
                ['n' => '46', 'l' => 'Sitting Judges'],
                ['n' => '1,200+', 'l' => 'Staff Members'],
                ['n' => '12L+', 'l' => 'Cases Disposed'],
                ['n' => '3.2L', 'l' => 'Pending Cases'],
            ];
            ?>
            <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="v2-stat">
                    <div class="v2-stat-num"><?php echo e($s['n']); ?></div>
                    <div class="v2-stat-lbl"><?php echo e($s['l']); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function changeFontSize(dir) {
    const root = document.documentElement;
    const current = parseFloat(getComputedStyle(root).fontSize);
    if (dir === 0) root.style.fontSize = '16px';
    else root.style.fontSize = Math.max(12, Math.min(22, current + dir * 2)) + 'px';
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/pages/home-v2.blade.php ENDPATH**/ ?>