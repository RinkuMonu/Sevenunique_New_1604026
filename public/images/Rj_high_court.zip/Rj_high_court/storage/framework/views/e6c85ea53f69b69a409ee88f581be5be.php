<?php $__env->startSection('title', 'Hon’ble Judges - High Court of Rajasthan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid py-4">

    <div class="row mb-4">
        <div class="col-12">
            <div class="bg-white shadow-sm rounded-4 p-4 border" style="border-left: 5px solid var(--hc-green-dark) !important;">
                <h2 class="fw-bold mb-2" style="color: var(--text-dark); font-family: var(--font-display);">
                    Hon’ble Judges
                </h2>
                <p class="text-muted mb-0" style="font-family: var(--font-body);">
                    High Court of Rajasthan
                </p>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-lg-12">

            <div class="card border-0 shadow-sm rounded-4 mb-4 overflow-hidden" style="border: 1px solid var(--border) !important;">
                <div class="card-header py-3" style="background-color: var(--hc-green-dark); color: var(--hc-text-light);">
                    <h4 class="mb-0 fw-semibold" style="font-family: var(--font-display);">
                        Acting Chief Justice
                    </h4>
                </div>

                <div class="card-body" style="background-color: var(--cream);">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 col-md-6">
                            <div class="judge-card text-center">
                                <div class="judge-image">
                                    <img
                                        src="<?php echo e(asset('img/judges/spsharmanew.jpg')); ?>"
                                        alt="Sanjeev Prakash Sharma"
                                        class="img-fluid"
                                    >
                                </div>

                                <div class="judge-content">
                                    <h5 class="judge-name">
                                        Sanjeev Prakash Sharma
                                    </h5>
                                    <p class="judge-designation">
                                        The Acting Chief Justice
                                    </p>
                                    <a href="spsharma.php" class="btn btn-judge-primary btn-sm rounded-pill px-4">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden" style="border: 1px solid var(--border) !important;">
                <div class="card-header py-3" style="background-color: var(--hc-green-light); color: var(--hc-text-light);">
                    <h4 class="mb-0 fw-semibold" style="font-family: var(--font-display);">
                        Hon’ble Judges
                    </h4>
                </div>

                <div class="card-body" style="background-color: var(--cream);">
                    <div class="row g-4">

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/psbhati.jpg')); ?>" alt="Pushpendra Singh Bhati">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Dr. Pushpendra Singh Bhati
                                    </h6>
                                    <a href="pushpendrasinghbhati.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/vnkmathur1.jpg')); ?>" alt="Vinit Kumar Mathur">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Vinit Kumar Mathur
                                    </h6>
                                    <a href="vinitkmathur.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/honindsingh.jpg')); ?>" alt="Inderjeet Singh">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Inderjeet Singh
                                    </h6>
                                    <a href="honindersingh.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/arunmonga.jpg')); ?>" alt="Arun Monga">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Arun Monga
                                    </h6>
                                    <a href="arun-monga.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/mkgoyal.jpg')); ?>" alt="Mahendar Kumar Goyal">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Mahendar Kumar Goyal
                                    </h6>
                                    <a href="mkgoyal.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/munnurilaxman.jpg')); ?>" alt="Munnuri Laxman">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Munnuri Laxman
                                    </h6>
                                    <a href="munnuri-laxman.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/farjandali.jpg')); ?>" alt="Farjand Ali">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Farjand Ali
                                    </h6>
                                    <a href="farjandali.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-6">
                            <div class="judge-card">
                                <div class="judge-image">
                                    <img src="<?php echo e(asset('img/judges/sudeshbansal.jpg')); ?>" alt="Sudesh Bansal">
                                </div>
                                <div class="judge-content">
                                    <h6 class="judge-name">
                                        Sudesh Bansal
                                    </h6>
                                    <a href="sudeshbansal.php" class="btn btn-judge-outline btn-sm rounded-pill px-3">
                                        View Profile
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>

    </div>

</div>

<style>
    /* ========================================================
       Judge Cards & Components - High Court Branding Theme
       ======================================================== */

    .judge-card {
        background: #ffffff;
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        overflow: hidden;
        box-shadow: var(--shadow-sm);
        transition: transform 0.3s ease, box-shadow 0.3s ease, border-color 0.3s ease;
        height: 100%;
    }

    .judge-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-md);
        border-color: var(--sage); /* #6B8F71 Brand Sage Border on Hover */
    }

    .judge-image {
        overflow: hidden;
        background-color: var(--warm-white);
        border-bottom: 1px solid var(--border);
    }

    .judge-image img {
        width: 100%;
        height: 280px;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .judge-card:hover img {
        transform: scale(1.05);
    }

    .judge-content {
        padding: 18px;
        text-align: center;
        background: #ffffff;
    }

    .judge-name {
        font-family: var(--font-display);
        font-weight: 700;
        color: var(--text-dark);
        margin-bottom: 12px;
        min-height: 45px;
        font-size: 1rem;
        line-height: 1.4;
    }

    .judge-designation {
        font-family: var(--font-body);
        color: var(--sage-dark); /* #3D5C42 Dark Sage Text */
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 15px;
    }

    /* ---- High Court Custom Buttons ---- */
    
    /* Solid Primary Button for Chief Justice Card */
    .btn-judge-primary {
        background-color: var(--forest); /* #2D5016 Core Forest Green */
        color: #ffffff;
        border: 1px solid var(--forest);
        font-family: var(--font-body);
        font-weight: 500;
        transition: all 0.2s ease;
    }

    .btn-judge-primary:hover, .btn-judge-primary:focus {
        background-color: var(--hc-green-dark); /* #1b431c On Hover */
        border-color: var(--hc-green-dark);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(27, 67, 28, 0.2);
    }

    /* Outline Button for Judges Grid */
    .btn-judge-outline {
        background-color: transparent;
        color: var(--forest); /* #2D5016 Core Forest Green */
        border: 1px solid var(--forest);
        font-family: var(--font-body);
        font-weight: 500;
        transition: all 0.2s ease;
    }

    .btn-judge-outline:hover, .btn-judge-outline:focus {
        background-color: var(--forest);
        color: #ffffff;
        box-shadow: 0 4px 10px rgba(45, 80, 22, 0.15);
    }

    /* ---- Sidebar / Navigation List Group ---- */
    .list-group-item {
        border: none;
        padding: 14px 18px;
        font-family: var(--font-body);
        font-weight: 500;
        color: var(--text-dark);
        background-color: transparent;
        transition: all 0.2s ease-in-out;
    }

    .list-group-item:hover {
        background: var(--sage-light); /* Soft background on hover */
        color: var(--forest);         /* #2D5016 Text Color on hover */
        padding-left: 22px;            
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function changeFontSize(dir) {
    const root = document.documentElement;
    const current = parseFloat(getComputedStyle(root).fontSize);

    if (dir === 0) {
        root.style.fontSize = '16px';
    } else {
        root.style.fontSize =
            Math.max(12, Math.min(22, current + dir * 2)) + 'px';
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/pages/judges.blade.php ENDPATH**/ ?>