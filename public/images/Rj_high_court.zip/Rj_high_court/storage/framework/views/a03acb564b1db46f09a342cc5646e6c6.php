<!-- Font Awesome Link (यदि मुख्य पेज पर पहले से न हो) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<style>
    :root {
        --hc-primary: #002b66;
        --hc-blue: #003366;
        --hc-light-blue: #e6f0fa;
        --hc-accent: #f1b24a;
        --hc-card-bg: #ffffff;
        --hc-text-main: #334155;
        --hc-text-muted: #64748b;
        --hc-border-light: #f1f5f9;
        
        --icon-blue-glow: #0284c7;
        --icon-orange-glow: #f97316;
    }

    /* --- SIDEBAR CONTAINER --- */
    .hc-sidebar {
        background: transparent;
        display: flex;
        flex-direction: column;
        gap: 24px;
        padding-bottom: 20px;
    }

    /* --- SIDEBAR CARD STYLING --- */
    .hc-sidebar-card {
        background: var(--hc-card-bg);
        border-radius: 20px;
        padding: 24px;
        box-shadow: 0 10px 30px rgba(0, 43, 102, 0.03);
        border: 1px solid #f1f5f9;
        border: 1px solid var(--hc-border);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .hc-sidebar-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 15px 35px rgba(0, 43, 102, 0.06);
    }

    /* Card Heading */
    .hc-sidebar-card h5 {
        font-size: 15px;
        font-weight: 700;
        color: var(--hc-primary);
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        border-bottom: 2px solid var(--hc-light-blue);
        padding-bottom: 10px;
        
    }

    .hc-sidebar-card h5 i {
        color: var(--icon-blue-glow);
    }

    /* --- VERTICAL NAVIGATION --- */
    .hc-sidebar-nav {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .hc-sidebar-nav-item {
        position: relative;
    }

    /* Regular Sidebar Link */
    .hc-sidebar-link {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 11px 16px;
        color: var(--hc-text-main);
        font-size: 13.5px;
        font-weight: 500;
        text-decoration: none;
        border-radius: 10px;
        transition: all 0.25s ease;
        background-color: transparent;
    }

    .hc-sidebar-link div {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .hc-sidebar-link div i {
        font-size: 14px;
        color: var(--hc-text-muted);
        transition: color 0.25s;
    }

    /* Hover States for Main Item */
    .hc-sidebar-link:hover,
    .hc-sidebar-nav-item:hover .hc-sidebar-link {
        background-color: var(--hc-light-blue);
        color: var(--hc-blue);
        font-weight: 600;
    }

    .hc-sidebar-link:hover div i,
    .hc-sidebar-nav-item:hover .hc-sidebar-link div i {
        color: var(--hc-blue);
    }

    /* Arrow icon styling */
    .hc-sidebar-arrow {
        font-size: 10px;
        color: #cbd5e1;
        transition: transform 0.25s, color 0.25s;
    }

    /* --- HOVER DROPDOWN LOGIC (CSS & JS Powered) --- */
    .hc-sidebar-dropdown {
        display: none;
        list-style: none;
        padding: 6px 0 6px 36px;
        margin: 0;
        flex-direction: column;
        gap: 2px;
    }

    .hc-sidebar-dropdown a {
        display: block;
        padding: 8px 12px;
        color: var(--hc-text-muted);
        font-size: 13px;
        text-decoration: none;
        border-radius: 6px;
        transition: all 0.2s;
    }

    .hc-sidebar-dropdown a:hover {
        color: var(--hc-blue);
        background-color: #f8fafc;
        padding-left: 16px;
    }

    /* CSS Hover Effect for Dropdown Display */
    .hc-sidebar-nav-item:hover .hc-sidebar-dropdown {
        display: flex;
    }

    /* Chevron rotation on hover */
    .hc-sidebar-nav-item:hover .hc-sidebar-arrow {
        transform: rotate(90deg);
        color: var(--hc-blue);
    }

    /* --- NOTIFICATION WIDGET --- */
    .hc-widget-bell {
        background: #fff8eb;
        border: 1px solid #ffeacc;
        border-radius: 14px;
        padding: 15px;
        display: flex;
        gap: 12px;
        align-items: flex-start;
        margin-top: 10px;
    }

    .hc-widget-bell i {
        color: var(--icon-orange-glow);
        font-size: 16px;
        margin-top: 2px;
    }

    .hc-widget-bell-text h6 {
        font-size: 13px;
        font-weight: 700;
        margin: 0;
        color: #7c2d12;
    }

    .hc-widget-bell-text p {
        font-size: 12px;
        margin: 4px 0 0 0;
        color: #9a3412;
        line-height: 1.4;
    }
</style>

<!-- SIDEBAR HTML CONTAINER -->
<div class="hc-sidebar">

    <!-- Card 1: Main Navigation Module -->
    <div class="hc-sidebar-card">
        <h5><i class="fa-solid fa-gavel"></i> Quick Access Menu</h5>
        <ul class="hc-sidebar-nav">
            
            <!-- Dropdown Item 1 (Judges Profile) -->
            <li class="hc-sidebar-nav-item">
                <a href="#" class="hc-sidebar-link">
                    <div><i class="fa-solid fa-user-tie"></i> Hon'ble Judges</div>
                    <i class="fa-solid fa-chevron-right hc-sidebar-arrow"></i>
                </a>
                <ul class="hc-sidebar-dropdown">
                    <li><a href="#">Chief Justice</a></li>
                    <li><a href="#">Sitting Judges</a></li>
                    <li><a href="#">Former Judges</a></li>
                </ul>
            </li>

            <!-- Dropdown Item 2 (Recruitment Portal) -->
            <li class="hc-sidebar-nav-item">
                <a href="#" class="hc-sidebar-link">
                    <div><i class="fa-solid fa-briefcase"></i> Recruitment</div>
                    <i class="fa-solid fa-chevron-right hc-sidebar-arrow"></i>
                </a>
                <ul class="hc-sidebar-dropdown">
                    <li><a href="#">Current Openings</a></li>
                    <li><a href="#">Results & Answer Keys</a></li>
                    <li><a href="#">Archived Notifications</a></li>
                </ul>
            </li>

            <!-- Dropdown Item 3 (Lok Adalat) -->
            <li class="hc-sidebar-nav-item">
                <a href="#" class="hc-sidebar-link">
                    <div><i class="fa-solid fa-gavel"></i> Lok Adalat</div>
                    <i class="fa-solid fa-chevron-right hc-sidebar-arrow"></i>
                </a>
                <ul class="hc-sidebar-dropdown">
                    <li><a href="#">Schedule</a></li>
                    <li><a href="#">Daily Panel List</a></li>
                    <li><a href="#">Awards / Orders</a></li>
                </ul>
            </li>

            <!-- Dropdown Item 4 (Mediation Centre) -->
            <li class="hc-sidebar-nav-item">
                <a href="#" class="hc-sidebar-link">
                    <div><i class="fa-solid fa-scale-balanced"></i> Mediation Centre</div>
                    <i class="fa-solid fa-chevron-right hc-sidebar-arrow"></i>
                </a>
                <ul class="hc-sidebar-dropdown">
                    <li><a href="#">About Centre</a></li>
                    <li><a href="#">Mediation Rules</a></li>
                    <li><a href="#">Panel of Mediators</a></li>
                </ul>
            </li>

            <!-- Dropdown Item 5 (RTI Cell) -->
            <li class="hc-sidebar-nav-item">
                <a href="#" class="hc-sidebar-link">
                    <div><i class="fa-solid fa-file-invoice"></i> RTI Cell</div>
                    <i class="fa-solid fa-chevron-right hc-sidebar-arrow"></i>
                </a>
                <ul class="hc-sidebar-dropdown">
                    <li><a href="#">RTI Rules</a></li>
                    <li><a href="#">PIO / Appellate Authority</a></li>
                    <li><a href="#">Application Status</a></li>
                </ul>
            </li>
        </ul>
    </div>

    <!-- Card 2: Notice Board & Alerts -->
    <div class="hc-sidebar-card">
        <h5><i class="fa-solid fa-bullhorn" style="color: var(--icon-orange-glow);"></i> Notice Board</h5>
        
        <div class="hc-widget-bell">
            <i class="fa-solid fa-circle-exclamation fa-bounce"></i>
            <div class="hc-widget-bell-text">
                <h6>Notice regarding e-Filing</h6>
                <p>Mandatory e-filing for commercial disputes has been activated from May 2026.</p>
            </div>
        </div>

        <div class="hc-widget-bell" style="background: #f0fdf4; border: 1px solid #bbf7d0;">
            <i class="fa-solid fa-calendar-days" style="color: #16a34a;"></i>
            <div class="hc-widget-bell-text">
                <h6 style="color: #14532d;">High Court Calendar</h6>
                <p style="color: #166534;">Updated list of institutional holidays for the current year is now live.</p>
            </div>
        </div>
    </div>

</div><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/layouts/partials/sidebar-v1.blade.php ENDPATH**/ ?>