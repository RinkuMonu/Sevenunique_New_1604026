<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'High Court of Rajasthan'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/v1-style.css')); ?>">
    
    <style>
        /* Modern Structural Flexbox System to avoid any overflow crashes */
        .app-layout-container {
            display: flex;
            min-height: 100vh;
            width: 100%;
        }
        
        #main-content {
            flex-grow: 1;
            min-width: 0; 
            background-color: #f8f9fa;
            padding: 2rem 1.5rem;
        }

        /* Responsive Flow Handler Breakpoints */
        @media (max-width: 991.98px) {
            .app-layout-container {
                flex-direction: column; /* Stacks sidebar and page content vertically on phone screens */
            }
            #main-content {
                padding: 1.25rem 0.75rem;
            }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    
    <?php echo $__env->make('layouts.partials.header-v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="app-layout-container">
        
        
        <?php echo $__env->make('layouts.partials.sidebar-v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <main id="main-content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
    </div>

    
    <?php echo $__env->make('layouts.partials.footer-v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/layouts/main-v2.blade.php ENDPATH**/ ?>