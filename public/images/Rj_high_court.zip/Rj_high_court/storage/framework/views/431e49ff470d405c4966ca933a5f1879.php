<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Rajasthan High Court | Executive Portal'); ?></title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        display: ['Outfit', 'sans-serif'],
                    },
                    colors: {
                        court: {
                            dark: '#0B132B',
                            navy: '#1C2541',
                            royal: '#3A506B',
                            gold: '#F4D068',
                            goldHover: '#E5B842',
                        }
                    }
                }
            }
        }
    </script>

    <style>
        /* Smooth Modern Scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #0B132B; }
        ::-webkit-scrollbar-thumb { background: #1C2541; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #3A506B; }

        /* Premium Glassmorphism Utility */
        .glass-panel {
            background: rgba(28, 37, 65, 0.45);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border: 1px solid rgba(255, 255, 255, 0.07);
        }
        
        .glass-card-hover {
            transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .glass-card-hover:hover {
            transform: translateY(-5px);
            background: rgba(28, 37, 65, 0.65);
            border-color: rgba(244, 208, 104, 0.3);
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.5);
        }
    </style>
</head>
<body class="bg-court-dark text-slate-100 font-sans selection:bg-court-gold selection:text-court-dark overflow-x-hidden">

    <div class="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px] pointer-events-none"></div>
    <div class="absolute top-20 right-1/4 w-80 h-80 bg-court-gold/5 rounded-full blur-[100px] pointer-events-none"></div>

    <?php echo $__env->make('website.layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="bg-court-navy/80 border-y border-white/5 py-3 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 flex items-center overflow-hidden">
            <span class="bg-gradient-to-r from-court-gold to-yellow-500 text-court-dark text-xs font-bold uppercase tracking-wider px-3 py-1 rounded shadow-sm z-10 flex items-center gap-1.5 shrink-0">
                <span class="flex h-2 w-2 relative">
                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-court-dark opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-court-dark"></span>
                </span>
                Live Updates
            </span>
            <marquee class="text-sm font-medium text-slate-300 ml-4 tracking-wide" behavior="scroll" direction="left" scrollamount="4">
                🔥 Revised SOP for secure high-speed digital courtroom streaming inside Rajasthan benches active now. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ⚡ Dynamic daily roster configuration modules deployed seamlessly.
            </marquee>
        </div>
    </div>

    <main class="min-h-[70vh]">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('website.layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/website/layout/main.blade.php ENDPATH**/ ?>