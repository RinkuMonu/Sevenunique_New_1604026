<footer class="text-white pt-5 pb-3" style="background-color: #1a1a1a; border-top: 4px solid var(--gold-accent);">
    <div class="container">
        <div class="row g-4">
            
            <div class="col-md-4 footer-links">
                <h5 class="text-uppercase fw-bold small text-warning mb-3">Important Links</h5>
                <div class="row">
                    <div class="col-6">
                        <a href="#">The President of India</a>
                        <a href="#">Prime Minister of India</a>
                        <a href="#">Supreme Court of India</a>
                        <a href="#">Indian Parliament</a>
                    </div>
                    <div class="col-6">
                        <a href="#">Government of India</a>
                        <a href="#">Government of Rajasthan</a>
                        <a href="#">District Courts</a>
                        <a href="#">National Judicial Academy</a>
                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <h5 class="text-uppercase fw-bold small text-warning mb-3">Get In Touch</h5>
                <div class="row g-3" style="font-size: 13px; color: #ddd;">
                    <div class="col-6 border-end border-secondary">
                        <p class="mb-1 text-white fw-bold"><i class="fa-solid fa-location-dot text-warning me-1"></i> Principal Seat Jodhpur</p>
                        <p class="mb-1">e-Services Helpline: 9414056204</p>
                        <p class="mb-0">hc-rj[at]nic[dot]in</p>
                    </div>
                    <div class="col-6">
                        <p class="mb-1 text-white fw-bold"><i class="fa-solid fa-location-dot text-warning me-1"></i> High Court Bench Jaipur</p>
                        <p class="mb-1">e-Services Helpline: 7023103127</p>
                        <p class="mb-0">hcjaipur-rj[at]nic[dot]in</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 text-md-end text-start">
                <h5 class="text-uppercase fw-bold small text-warning mb-3">Portal Policy</h5>
                <p class="small text-muted mb-0" style="font-size: 12px;">
                    Website designed and developed for demo mapping purposes. Powered by Laravel 10 Framework.
                </p>
                <div class="mt-3 text-muted small" style="font-size: 11px;">
                    <i class="fa-solid fa-shield-halved text-secondary me-1"></i> Secure Connection Enabled
                </div>
            </div>

        </div>

        <hr class="border-secondary my-4">

        <div class="row text-muted" style="font-size: 12px;">
            <div class="col-md-6 text-md-start text-center">
                &copy; <?php echo e(date('Y')); ?> Rajasthan High Court. All Rights Reserved.
            </div>
            <div class="col-md-6 text-md-end text-center mt-2 mt-md-0">
                Content Managed by High Court Registry // Hosted by National Informatics Centre (NIC)
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/website/layout/partials/footer.blade.php ENDPATH**/ ?>