<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<style>
    :root {
        --hc-blue: #003366;
        --hc-light-blue: #e6f0fa;
        --hc-nav-text: #333333;
        --hc-border: #dcdcdc;
    }

    body {
        margin: 0;
        padding: 0;
        overflow-x: hidden;
    }

    /* --- 1. TOP HEADER BAR --- */
    .hc-top-header {
        background-color: #ffffff;
        padding: 15px 40px 35px 40px; /* नीचे पैडिंग ताकि नेवबार इसके ऊपर ओवरलैप हो सके */
        border-bottom: 1px solid var(--hc-border);
        position: relative;
        z-index: 1;
    }
    .hc-logo-area {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .hc-emblem {
        height: 60px;
        width: auto;
    }
    .hc-title-text h1 {
        font-family: 'Georgia', serif;
        font-size: 24px;
        font-weight: bold;
        color: #111111;
        margin: 0;
    }
    .hc-title-text p {
        font-size: 14px;
        color: #555555;
        margin: 0;
        font-weight: 500;
    }

    /* Top Right Controls */
    .hc-controls {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 15px;
    }
    .hc-font-btn {
        background: #f1f3f5;
        border: 1px solid #ced4da;
        padding: 2px 8px;
        font-size: 12px;
        font-weight: 600;
        color: #495057;
        text-decoration: none;
        border-radius: 3px;
    }
    .hc-font-btn:hover { background: #e2e6ea; }
    
    .hc-round-icon {
        width: 32px;
        height: 32px;
        background: #003366;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
    }
    .hc-search-wrapper {
        position: relative;
        width: 250px;
    }
    .hc-search-input {
        width: 100%;
        padding: 6px 40px 6px 15px;
        font-size: 13px;
        border: 1px solid #cccccc;
        border-radius: 20px;
        background-color: #f8f9fa;
        outline: none;
    }
    .hc-search-btn {
        position: absolute;
        right: 2px;
        top: 2px;
        bottom: 2px;
        border: none;
        background: var(--hc-blue);
        color: #ffffff;
        padding: 0 15px;
        border-radius: 20px;
        font-size: 12px;
        transition: background 0.2s;
    }
    .hc-search-btn:hover { background: #002244; }


    /* --- 2. NAVBAR (OVERLAPPING LOGIC) --- */
    .hc-navbar {
        background-color: transparent !important;
        padding: 0 !important;
        margin-top: -25px !important; /* नैवबार को ऊपर वाले हेडर पर ओवरलैप करने का लॉजिक */
        position: relative;
        z-index: 10 !important;
    }

    .hc-navbar-container {
        background-color: #ffffff;
        margin: 0 40px !important; /* इसकी विड्थ: 100% minus लेफ्ट-राइट 40px गैप */
        padding: 6px 20px !important;
        border-radius: 14px; 
        border: 1px solid #eaeaea;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
    }

    .hc-nav-link {
        color: var(--hc-nav-text) !important;
        font-size: 13px;
        font-weight: 500;
        padding: 8px 10px !important;
        border-radius: 6px;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 4px;
        text-decoration: none;
    }

    .hc-nav-item.home-link .hc-nav-link {
        background-color: var(--hc-light-blue);
        color: var(--hc-blue) !important;
        border: 1px solid #b3d1ff;
    }
    .hc-nav-link:hover {
        background-color: #f1f3f5;
        color: var(--hc-blue) !important;
    }

    .hc-navbar .dropdown-toggle::after {
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        content: "\f107";
        border: none;
        vertical-align: middle;
        font-size: 10px;
        margin-left: 4px;
    }

    .hc-dropdown-menu {
        border: 1px solid var(--hc-border);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        font-size: 13px;
        border-top: 3px solid var(--hc-blue);
        border-radius: 0 0 8px 8px;
        margin-top: 5px;
    }

    /* Responsive adjustments for Header & Navbar */
    @media (max-width: 991px) {
        .hc-navbar { margin-top: -15px !important; }
        .hc-navbar-container { margin: 0 15px !important; } /* मोबाइल पर विड्थ बढ़ जाएगी क्योंकि मार्जिन 15px हो गया है */
        .hc-top-header { padding: 15px 20px 25px 20px; }
        .hc-controls { justify-content: flex-start; }
    }

    @media (min-width: 1200px) {
        .hc-navbar .nav-item.dropdown:hover .hc-dropdown-menu {
            display: block;
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            transition: all 0.3s ease;
        }
        .hc-navbar .nav-item.dropdown .hc-dropdown-menu {
            display: block;
            opacity: 0;
            visibility: hidden;
            transform: translateY(10px);
            transition: all 0.2s ease;
        }
    }
</style>

<div class="hc-top-header">
    <div class="row align-items-center">
        <div class="col-md-7 col-12 hc-logo-area">
            <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Emblem" class="hc-emblem">
            <div class="hc-title-text">
                <h1>Rajasthan High Court</h1>
                <p>(राजस्थान उच्च न्यायालय)</p>
            </div>
        </div>
        
        <div class="col-md-5 col-12 hc-controls mt-3 mt-md-0">
    <div class="d-flex align-items-center gap-1">
        <!-- फ़ॉन्ट साइज कंट्रोल्स -->
        <a href="#" class="hc-font-btn">A-</a>
        <a href="#" class="hc-font-btn">A</a>
        <a href="#" class="hc-font-btn">A+</a>
        
        <!-- थीम कंट्रोल्स (नए जोड़े गए बटन) -->
        <button id="hc-light-theme-btn" class="hc-theme-btn active" title="Light Theme">
            <i class="fa-solid fa-sun"></i>
        </button>
        <button id="hc-dark-theme-btn" class="hc-theme-btn" title="Dark Theme">
            <i class="fa-solid fa-moon"></i>
        </button>
    </div>
    <!-- <div class="hc-round-icon">
        <i class="fa-solid fa-gavel" style="font-size: 13px;"></i>
    </div>
    <div class="hc-search-wrapper">
        <input type="text" class="hc-search-input" placeholder="Search here...">
        <button class="hc-search-btn"><i class="fa-solid fa-magnifying-glass"></i></button>
    </div> -->
</div>
    </div>
</div>

<nav class="navbar navbar-expand-xl hc-navbar w-100">
    <div class="container-fluid hc-navbar-container">
        <button class="navbar-toggler ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#hcMenuContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="hcMenuContent">
            <ul class="navbar-nav w-100 justify-content-between">
                <li class="nav-item hc-nav-item home-link">
                    <a class="hc-nav-link" href="<?php echo e(route('home')); ?>"><i class="fa-solid fa-house"></i> Home</a>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="fa-solid fa-bars"></i> Menu</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('history')); ?>">History</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('registrar')); ?>">Registrar General</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Cause List</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="#">Daily Cause List</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Case Status</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="#">Search by Number</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Live List / Advocate Wise</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="#">Live Display Board</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Judgments</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="#">Reportable Judgments</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">e-True Copy</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="#">Apply Online</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item">
                    <a class="hc-nav-link" href="#">Latest Updates</a>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Archive</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="#">Old Notifications</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item dropdown">
                    <a class="hc-nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">e-Services</a>
                    <ul class="dropdown-menu hc-dropdown-menu">
                        <li><a class="dropdown-item" href="#">e-Filing</a></li>
                    </ul>
                </li>
                <li class="nav-item hc-nav-item"><a class="hc-nav-link" href="#">Virtual Justice Clock</a></li>
                <li class="nav-item hc-nav-item"><a class="hc-nav-link" href="#">Commercial Courts</a></li>
                <li class="nav-item hc-nav-item"><a class="hc-nav-link" href="#">eLR-Raj Portal</a></li>
                <li class="nav-item hc-nav-item"><a class="hc-nav-link" href="#">JJC</a></li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/layouts/partials/header-v1.blade.php ENDPATH**/ ?>