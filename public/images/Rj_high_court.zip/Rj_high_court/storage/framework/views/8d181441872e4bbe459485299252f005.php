<header class="shadow-sm bg-white sticky-top">
    <div class="bg-navy text-white py-1 font-monospace" style="font-size: 0.8rem;">
        <div class="container d-flex justify-content-between align-items-center">
            <div>
                <span class="me-3"><i class="fa-solid fa-calendar-days text-gold me-1"></i> <?php echo e(date('l, F d, Y')); ?></span>
            </div>
            <div class="d-flex align-items-center gap-3">
                <a href="#" class="text-white text-decoration-none">A-</a>
                <a href="#" class="text-white text-decoration-none">A</a>
                <a href="#" class="text-white text-decoration-none">A+</a>
                <span class="text-muted">|</span>
                <a href="#" class="text-white text-decoration-none">हिन्दी</a>
            </div>
        </div>
    </div>

    <div class="container py-3">
        <div class="row align-items-center">
            <div class="col-md-8 d-flex align-items-center">
                <i class="fa-solid fa-building-columns fa-3x text-navy me-3"></i>
                <div>
                    <h1 class="h4 mb-0 fw-bold text-uppercase" style="color: var(--hc-navy); letter-spacing: 0.5px;">
                        Rajasthan High Court
                    </h1>
                    <small class="text-muted fw-medium">राजस्थान उच्च न्यायालय</small>
                </div>
            </div>
            <div class="col-md-4 text-end d-none d-md-block">
                <span class="badge bg-light text-dark border p-2">
                    <i class="fa-solid fa-gavel text-gold me-1"></i> Satyaméva Jayatē
                </span>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-navy border-top border-warning border-3 py-1">
        <div class="container">
            <button class="navbar-toggler" type="text-lg" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 card-text">
                    <li class="nav-item"><a class="nav-link active" href="#"><i class="fa-solid fa-house"></i></a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Case Status</a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-menu-item dropdown-item" href="#">By Case Number</a></li>
                            <li><a class="dropdown-menu-item dropdown-item" href="#">By Party Name</a></li>
                            <li><a class="dropdown-menu-item dropdown-item" href="#">By Advocate</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Cause List</a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Jodhpur Bench</a></li>
                            <li><a class="dropdown-item" href="#">Jaipur Bench</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#">Judgments</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Roster</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Recruitment</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">e-Services</a></li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control form-control-sm me-2" type="search" placeholder="Search Judgments...">
                    <button class="btn btn-sm btn-gold" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                </form>
            </div>
        </div>
    </nav>
</header><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/website/layouts/partials/header.blade.php ENDPATH**/ ?>