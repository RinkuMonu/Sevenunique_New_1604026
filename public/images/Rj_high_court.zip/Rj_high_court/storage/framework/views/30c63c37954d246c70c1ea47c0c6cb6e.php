

<?php $__env->startSection('title', 'Home - Rajasthan High Court, Jaipur Bench'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    :root {
        --hc-blue: #003366;
        --hc-light-blue: #e6f0fa;
        --hc-nav-text: #333333;
        --hc-border: #dcdcdc;
    }

    /* --- HERO SLIDER / BANNER SECTION --- */
    .hc-hero-wrapper {
        padding: 0 !important;
        margin: 0 !important;
        width: 100%;
        overflow: hidden;
    }

    .hc-hero-section {
        position: relative;
        width: 100%;
        height: 520px; 
        display: flex;
        align-items: center;
        border-radius: 0px; 
        border: none;
        overflow: hidden;
    }

    /* --- BACKGROUND MANAGEMENT LAYER --- */
    .hc-hero-bg {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-size: cover;
        background-repeat: no-repeat;
        z-index: 1;
        opacity: 0;
        transition: opacity 0.8s ease-in-out; /* Smooth fade transition */
    }

    .hc-hero-bg.active {
        opacity: 1;
    }

    /* Desktop Background Layouts */
    .hc-bg-1 {
        background-image: linear-gradient(90deg, 
                    rgba(255,255,255,0.96) 0%, 
                    rgba(255,255,255,0.85) 25%, 
                    rgba(255,255,255,0.10) 45%, 
                    rgba(255,255,255,0) 70%), 
                    url("<?php echo e(asset('assets/hero/image1.jpg')); ?>");
        background-position: center right 15%;
    }

    .hc-bg-2 {
        background-image: linear-gradient(90deg, 
                    rgba(255,255,255,0.96) 0%, 
                    rgba(255,255,255,0.85) 25%, 
                    rgba(255,255,255,0.10) 45%, 
                    rgba(255,255,255,0) 70%), 
                    url("<?php echo e(asset('assets/hero/image2.jpg')); ?>"); /* Path to your second image */
        background-position: center right 15%;
    }

    /* Tablet Screens */
    @media (max-width: 1024px) {
        .hc-bg-1, .hc-bg-2 {
            background-position: center right 5%; 
        }
        .hc-hero-section { height: 480px; }
    }

    /* Mobile Screens Layout Updates */
    @media (max-width: 768px) {
        .hc-hero-section {
            height: auto;
            min-height: 380px; 
            padding: 50px 0 80px 0; 
        }
        .hc-bg-1 {
            background: linear-gradient(180deg, 
                        rgba(255,255,255,0.98) 0%, 
                        rgba(255,255,255,0.88) 50%, 
                        rgba(255,255,255,0.30) 100%), 
                        url("<?php echo e(asset('assets/hero/image1.jpg')); ?>") no-repeat;
            background-size: cover;
            background-position: center center;
        }
        .hc-bg-2 {
            background: linear-gradient(180deg, 
                        rgba(255,255,255,0.98) 0%, 
                        rgba(255,255,255,0.88) 50%, 
                        rgba(255,255,255,0.30) 100%), 
                        url("<?php echo e(asset('assets/hero/image2.jpg')); ?>") no-repeat;
            background-size: cover;
            background-position: center center;
        }
        .hc-hero-content h2 { font-size: 28px !important; }
        .hc-banner-arrow { display: none !important; }
        .hc-slider-dots { bottom: 65px; }
    }

    /* Extra Small Phones */
    @media (max-width: 480px) {
        .hc-hero-section { min-height: 340px; padding: 40px 0 75px 0; }
        .hc-hero-content h2 { font-size: 24px !important; }
    }

    .hc-hero-content-container {
        position: relative;
        width: 100%;
        padding: 0 60px; 
        box-sizing: border-box;
        margin-top: -40px; 
        z-index: 5; /* Sits securely above fading background layers */
    }

    @media (max-width: 1200px) {
        .hc-hero-content-container { padding: 0 40px; }
    }
    @media (max-width: 576px) {
        .hc-hero-content-container { padding: 0 20px; }
    }

    .hc-banner-arrow {
        position: absolute;
        top: 45%; 
        transform: translateY(-50%);
        width: 44px;
        height: 44px;
        background: #ffffff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        color: #003366;
        text-decoration: none;
        z-index: 10;
        transition: all 0.2s ease;
    }
    .hc-banner-arrow:hover { background: #003366; color: #ffffff; }
    .hc-banner-arrow.left { left: 20px; }
    .hc-banner-arrow.right { right: 20px; }

    .hc-hero-content { max-width: 500px; }
    .hc-hero-content h2 { 
        font-family: 'Georgia', serif; 
        font-size: 40px; 
        font-weight: bold; 
        color: #111111; 
        line-height: 1.25; 
        margin-bottom: 12px; 
    }
    .hc-hero-content h2 span { color: #003366; }
    .hc-hero-content p { font-size: 15px; color: #555555; font-weight: 500; margin-bottom: 28px; }

    .hc-btn-explore {
        background-color: #003366;
        color: #ffffff !important;
        font-size: 14px;
        font-weight: 600;
        padding: 12px 26px;
        border-radius: 30px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 12px;
        transition: all 0.2s;
    }
    .hc-btn-explore:hover { background-color: #001f44; }
    .hc-btn-explore i { background: #ffffff; color: #003366; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; }

    .hc-slider-dots { position: absolute; bottom: 70px; left: 50%; transform: translateX(-50%); display: flex; gap: 8px; z-index: 10; }
    .hc-dot { width: 8px; height: 8px; background-color: rgba(0, 51, 102, 0.2); border-radius: 50%; cursor: pointer; transition: all 0.2s ease; }
    .hc-dot.active { background-color: #003366; width: 24px; border-radius: 10px; }

    /* --- QUICK ACCESS MAIN CONTAINER (FIXED ALIGNMENT) --- */
    .hc-quick-access-section { padding: 0; width: 100%; position: relative; z-index: 15; }
    .hc-qa-container {
        background-color: #ffffff;
        margin-top: -50px !important; 
        margin-left: 0 !important;
        margin-right: 0 !important;
        padding: 24px !important; 
        border-radius: 20px; 
        border: 1px solid #eaeaea;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05); 
        position: relative;
        overflow: visible !important; 
    }

    @media (max-width: 991px) {
        .hc-qa-container { margin-top: -40px !important; padding: 20px 15px !important; border-radius: 14px; }
    }

    .hc-section-title { font-size: 14px; font-weight: 700; color: #002b66; position: relative; padding-left: 12px; margin-bottom: 20px; }
    .hc-section-title::before { content: ''; position: absolute; left: 0; top: 2px; bottom: 2px; width: 3.5px; background-color: #003366; border-radius: 2px; }

    .hc-qa-grid { display: grid; grid-template-columns: repeat(9, 1fr); gap: 12px; position: relative; overflow: visible !important; }
    @media (max-width: 1400px) { .hc-qa-grid { grid-template-columns: repeat(5, 1fr); } }
    @media (max-width: 992px) { .hc-qa-grid { grid-template-columns: repeat(4, 1fr); } }
    @media (max-width: 768px) { .hc-qa-grid { grid-template-columns: repeat(3, 1fr); } }
    @media (max-width: 480px) { .hc-qa-grid { grid-template-columns: repeat(2, 1fr); } }

    .hc-qa-item-wrapper { position: relative; width: 100%; }
    .hc-qa-card {
        background: #ffffff; border: 1px solid #e8eef5; border-radius: 16px; padding: 16px 8px; text-align: center; text-decoration: none;
        display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; min-height: 110px; box-sizing: border-box; transition: all 0.2s ease-in-out;
    }
    .hc-qa-icon-wrapper { color: #003366; margin-bottom: 10px; font-size: 20px; transition: transform 0.2s ease; }
    .hc-qa-card h6 { font-size: 12px; font-weight: 600; color: #475569; margin: 0; line-height: 1.3; }
    .hc-qa-card:hover { border-color: #003366; background-color: #f8faff; box-shadow: 0 4px 12px rgba(0,51,102,0.05); }
    .hc-qa-card:hover .hc-qa-icon-wrapper { transform: scale(1.05); }

    .hc-qa-dropdown {
        position: absolute; top: 100%; left: 50%; transform: translateX(-50%) translateY(10px); background: #ffffff; border: 1px solid #e2e8f0; border-top: 3px solid #003366; 
        border-radius: 8px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15); list-style: none; padding: 6px 0; margin: 5px 0 0 0; min-width: 190px; z-index: 99999; 
        opacity: 0; visibility: hidden; transition: opacity 0.2s ease, transform 0.2s ease, visibility 0.2s; pointer-events: none; 
    }
    .hc-qa-item-wrapper:hover .hc-qa-dropdown { opacity: 1 !important; visibility: visible !important; transform: translateX(-50%) translateY(0) !important; pointer-events: auto; }
    .hc-qa-dropdown li a { display: block; padding: 9px 16px; color: #334155; font-size: 12px; font-weight: 500; text-decoration: none; text-align: left; }
    .hc-qa-dropdown li a:hover { background: #f1f5f9; color: #003366; }

    /* --- LATEST UPDATES TICKER --- */
    .hc-ticker-section { padding: 25px 0 15px 0; } 
    .hc-ticker-container { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; display: flex; align-items: center; gap: 15px; padding: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.01); position: relative; }
    .hc-ticker-label { background: #002b66; color: #ffffff; padding: 8px 18px; font-weight: 700; font-size: 12px; border-radius: 8px; display: flex; align-items: center; gap: 6px; white-space: nowrap; z-index: 5; }
    .hc-ticker-content-wrapper { flex-grow: 1; overflow: hidden; position: relative; display: block; }
    .hc-ticker-track { display: inline-block; white-space: nowrap; padding-left: 100%; animation: ticker-marquee 30s linear infinite; }
    .hc-ticker-track:hover { animation-play-state: paused; }
    .hc-updates-list { display: inline-flex; align-items: center; gap: 30px; margin: 0; padding: 0; list-style: none; }
    .hc-updates-list li { display: inline-block; }
    .hc-update-item { font-size: 12px; font-weight: 500; color: #334155; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }
    .hc-update-item:hover { color: #002b66; }
    .hc-separator { color: #cbd5e1; font-weight: 300; font-size: 14px; list-style: none; }
    .hc-ticker-nav { display: flex; gap: 5px; padding-right: 10px; margin-left: auto; background: #ffffff; z-index: 5; padding-left: 10px; }
    .hc-tick-btn { width: 24px; height: 24px; border: 1px solid #cbd5e1; background: #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #64748b; text-decoration: none; }
    .hc-tick-btn:hover { background: #f8fafc; color: #002b66; }

    @keyframes ticker-marquee {
        0% { transform: translate3d(0, 0, 0); }
        100% { transform: translate3d(-100%, 0, 0); }
    }

    @media (max-width: 768px) {
        .hc-ticker-container { flex-direction: column; align-items: stretch; gap: 10px; padding: 8px; }
        .hc-ticker-label { width: 100%; justify-content: center; }
        .hc-ticker-content-wrapper { width: 100%; }
        .hc-ticker-track { padding-left: 100%; animation-duration: 18s; } 
        .hc-ticker-nav { display: none; } 
    }

    /* --- REWORKED LIVE STREAMING & JUDGMENTS CUSTOM CLASSES --- */
    .hc-media-judgments-section { padding: 25px 0 35px 0; }
    
    .hc-panel-card {
        background: #ffffff;
        border: 1px solid #eaeaea;
        border-radius: 20px;
        padding: 24px !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
    }

    .hc-panel-title {
        font-family: 'Georgia', serif;
        font-size: 20px;
        font-weight: 700;
        color: #111111;
        margin-bottom: 0;
    }

    .hc-tab-pills {
        background-color: #f8faff;
        border: 1px solid #e8eef5;
        border-radius: 30px !important;
        padding: 3px;
    }

    .hc-tab-pills .nav-link {
        color: #64748b;
        font-size: 12px;
        font-weight: 600;
        border-radius: 20px !important;
        padding: 6px 16px !important;
        transition: all 0.2s ease;
    }

    .hc-tab-pills .nav-link.active {
        background-color: var(--hc-blue) !important;
        color: #ffffff !important;
    }

    .hc-judgment-item {
        background: #ffffff;
        border: 1px solid #e8eef5;
        border-radius: 14px;
        padding: 16px;
        position: relative;
        overflow: hidden;
        transition: all 0.2s ease-in-out;
    }
    
    .hc-judgment-item:hover {
        border-color: var(--hc-blue);
        box-shadow: 0 4px 12px rgba(0, 51, 102, 0.04);
    }

    .hc-judgment-item::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
        background-color: var(--hc-blue);
        opacity: 0.7;
    }

    .hc-judgment-item h6 {
        font-size: 14px;
        font-weight: 600;
        color: #1e293b;
    }

    .hc-judgment-item p {
        font-size: 12.5px;
        color: #64748b;
        line-height: 1.4;
    }

    .hc-badge-custom {
        font-size: 10px;
        font-weight: 600;
        padding: 3px 8px;
        border-radius: 4px;
        display: inline-block;
        margin-bottom: 8px;
    }

    .hc-btn-outline-more {
        border: 1px solid #cbd5e1;
        color: #475569;
        font-size: 13px;
        font-weight: 600;
        padding: 10px 24px;
        border-radius: 30px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all 0.2s;
    }

    .hc-btn-outline-more:hover {
        border-color: var(--hc-blue);
        color: var(--hc-blue);
        background-color: #f8faff;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-2 px-md-5">

    <div class="hc-hero-wrapper">
        <div class="hc-hero-section" id="hcHeroSection">
            
            <div class="hc-hero-bg hc-bg-1 active"></div>
            <div class="hc-hero-bg hc-bg-2"></div>

            <a href="#" class="hc-banner-arrow left" id="prevSlideBtn"><i class="fa-solid fa-chevron-left"></i></a>
            <a href="#" class="hc-banner-arrow right" id="nextSlideBtn"><i class="fa-solid fa-chevron-right"></i></a>

            <div class="hc-hero-content-container">
                <div class="hc-hero-content">
                    <h2>Rajasthan High Court, <br><span>Jaipur Bench</span></h2>
                    <p>Committed to Justice. Dedicated to Transparency.</p>
                    <a href="#" class="hc-btn-explore">
                        Explore Services 
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="hc-slider-dots">
                <span class="hc-dot active" data-slide="0"></span>
                <span class="hc-dot" data-slide="1"></span>
            </div>
        </div>
    </div>

    <div class="hc-quick-access-section">
        <div class="row mx-0">
            <div class="col-12 px-0">
                <div class="hc-qa-container">
                    <h5 class="hc-section-title">Quick Access</h5>
                    
                    <div class="hc-qa-grid">
                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-gavel"></i></div>
                                <h6>Judgments</h6>
                            </a>
                            <ul class="hc-qa-dropdown">
                                <li><a href="#">Reportable Judgments</a></li>
                                <li><a href="#">Non-Reportable Judgments</a></li>
                                <li><a href="#">Latest Orders</a></li>
                            </ul>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-file-invoice"></i></div>
                                <h6>eNCR / Judgment Search</h6>
                            </a>
                            <ul class="hc-qa-dropdown">
                                <li><a href="#">Search by Case Number</a></li>
                                <li><a href="#">Search by Party Name</a></li>
                                <li><a href="#">Search by Advocate</a></li>
                            </ul>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-calendar-days"></i></div>
                                <h6>Roster</h6>
                            </a>
                            <ul class="hc-qa-dropdown">
                                <li><a href="#">Daily Roster</a></li>
                                <li><a href="#">Sitting List</a></li>
                                <li><a href="#">Urgent Roster</a></li>
                            </ul>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-user-plus"></i></div>
                                <h6>Recruitment</h6>
                            </a>
                            <ul class="hc-qa-dropdown">
                                <li><a href="#">Current Openings</a></li>
                                <li><a href="#">Results / Answer Keys</a></li>
                                <li><a href="#">Notifications</a></li>
                            </ul>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-wheelchair"></i></div>
                                <h6>Accessibility Committee</h6>
                            </a>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-circle-info"></i></div>
                                <h6>Right to Information</h6>
                            </a>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-cart-shopping"></i></div>
                                <h6>Procurement</h6>
                            </a>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-chalkboard-user"></i></div>
                                <h6>Display Board</h6>
                            </a>
                        </div>

                        <div class="hc-qa-item-wrapper">
                            <a href="#" class="hc-qa-card">
                                <div class="hc-qa-icon-wrapper"><i class="fa-solid fa-scale-balanced"></i></div>
                                <h6>M-Phila Cases</h6>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="hc-ticker-section">
        <div class="row mx-0">
            <div class="col-12 px-0">
                <div class="hc-ticker-container">
                    <div class="hc-ticker-label">
                        <i class="fa-solid fa-bullhorn"></i> Latest Updates
                    </div>
                    
                    <div class="hc-ticker-content-wrapper">
                        <div class="hc-ticker-track">
                            <ul class="hc-updates-list">
                                <li>
                                    <a href="#" class="hc-update-item">
                                        Silent WhatsApp Chat not to respond as on 10/07/2024 <span class="badge bg-danger" style="font-size: 9px; padding: 2px 4px;">NEW</span>
                                    </a>
                                </li>
                                <li class="hc-separator">/</li>
                                <li>
                                    <a href="#" class="hc-update-item">
                                        Important Point Corruption at RNSSR/PTNR in Rajasthan <span class="badge bg-danger" style="font-size: 9px; padding: 2px 4px;">NEW</span>
                                    </a>
                                </li>
                                <li class="hc-separator">/</li>
                                <li>
                                    <a href="#" class="hc-update-item">
                                        Accessibility Committee <span class="badge bg-danger" style="font-size: 9px; padding: 2px 4px;">NEW</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="hc-ticker-nav">
                        <a href="#" class="hc-tick-btn"><i class="fa-solid fa-chevron-left"></i></a>
                        <a href="#" class="hc-tick-btn"><i class="fa-solid fa-chevron-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <section class="hc-media-judgments-section">
        <div class="row g-4 mx-0">
            
            
            <div class="col-lg-6 px-0 pe-lg-3">
                <div class="hc-panel-card h-100">
                    <div class="d-flex align-items-center mb-4 pb-2 border-bottom">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-video text-danger"></i>
                            <h4 class="hc-panel-title">Republic Day Celebration</h4>
                        </div>
                    </div>
                    
                    <div class="ratio ratio-16x9 rounded-3 overflow-hidden border mb-3">
                        <iframe 
                            src="https://www.youtube.com/embed/xlxzatKJvn4"
                            title="YouTube video player"
                            allowfullscreen>
                        </iframe>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-6 px-0 ps-lg-3">
                <div class="hc-panel-card h-100">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4 pb-2 border-bottom">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-gavel" style="color: var(--hc-blue);"></i>
                            <h4 class="hc-panel-title">Latest Judgments</h4>
                        </div>
                        
                        <ul class="nav nav-pills hc-tab-pills" id="judgmentBenchTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="jodhpur-tab" data-bs-toggle="pill" data-bs-target="#jodhpur-judgments" type="button" role="tab" aria-controls="jodhpur-judgments" aria-selected="true">
                                    Jodhpur Main Seat
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="jaipur-tab" data-bs-toggle="pill" data-bs-target="#jaipur-judgments" type="button" role="tab" aria-controls="jaipur-judgments" aria-selected="false">
                                    Jaipur Bench
                                </button>
                            </li>
                        </ul>
                    </div>

                    <div class="tab-content" id="judgmentBenchTabsContent">
                        
                        <div class="tab-pane fade show active" id="jodhpur-judgments" role="tabpanel" aria-labelledby="jodhpur-tab">
                            <div class="d-flex flex-column gap-3">
                                <div class="hc-judgment-item">
                                    <span class="hc-badge-custom bg-success-subtle text-success border border-success-subtle">Civil Case</span>
                                    <h6 class="mb-1">Suomoto v. State of Rajasthan & Ors.</h6>
                                    <p class="mb-0 text-truncate-2">Judgment regarding guidelines for urban infrastructure development plans at Jodhpur region division.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3" style="font-size: 11px;">
                                        <span><i class="far fa-calendar-alt me-1"></i> 21.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 4.2 MB</span>
                                    </div>
                                </div>

                                <div class="hc-judgment-item">
                                    <span class="hc-badge-custom bg-danger-subtle text-danger border border-danger-subtle">Criminal Appeal</span>
                                    <h6 class="mb-1">Ramesh Kumar v. State of Rajasthan</h6>
                                    <p class="mb-0 text-truncate-2">Detailed parameters for grant of regular suspension of sentence under updated security acts.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3" style="font-size: 11px;">
                                        <span><i class="far fa-calendar-alt me-1"></i> 20.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 1.8 MB</span>
                                    </div>
                                </div>
                                <div class="hc-judgment-item">
                                    <span class="hc-badge-custom bg-danger-subtle text-danger border border-danger-subtle">Criminal Appeal</span>
                                    <h6 class="mb-1">Ramesh Kumar v. State of Rajasthan</h6>
                                    <p class="mb-0 text-truncate-2">Detailed parameters for grant of regular suspension of sentence under updated security acts.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3" style="font-size: 11px;">
                                        <span><i class="far fa-calendar-alt me-1"></i> 20.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 1.8 MB</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="jaipur-judgments" role="tabpanel" aria-labelledby="jaipur-tab">
                            <div class="d-flex flex-column gap-3">
                                <div class="hc-judgment-item">
                                    <span class="hc-badge-custom bg-warning-subtle text-warning-emphasis border border-warning-subtle">Writ Petition</span>
                                    <h6 class="mb-1">Mahendra Singh v. Technical Education Dept.</h6>
                                    <p class="mb-0 text-truncate-2">Interim operational structure orders regulating institutional affiliations and quota rosters within Jaipur division.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3" style="font-size: 11px;">
                                        <span><i class="far fa-calendar-alt me-1"></i> 21.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 2.9 MB</span>
                                    </div>
                                </div>

                                <div class="hc-judgment-item">
                                    <span class="hc-badge-custom bg-success-subtle text-success border border-success-subtle">Service Matter</span>
                                    <h6 class="mb-1">Smt. Anjali Sharma v. State Personnel Dept.</h6>
                                    <p class="mb-0 text-truncate-2">Adjudication over selection seniority structures and administrative reservation protocols under state rules.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3" style="font-size: 11px;">
                                        <span><i class="far fa-calendar-alt me-1"></i> 19.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 3.5 MB</span>
                                    </div>
                                </div>
                                <div class="hc-judgment-item">
                                    <span class="hc-badge-custom bg-success-subtle text-success border border-success-subtle">Service Matter</span>
                                    <h6 class="mb-1">Smt. Anjali Sharma v. State Personnel Dept.</h6>
                                    <p class="mb-0 text-truncate-2">Adjudication over selection seniority structures and administrative reservation protocols under state rules.</p>
                                    <div class="text-muted small mt-2 d-flex align-items-center gap-3" style="font-size: 11px;">
                                        <span><i class="far fa-calendar-alt me-1"></i> 19.05.2026</span>
                                        <span><i class="far fa-file-pdf text-danger me-1"></i> 3.5 MB</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="text-start mt-4">
                        <a href="#" class="hc-btn-outline-more">
                            View All Judgments <i class="fas fa-arrow-right text-muted" style="font-size: 11px;"></i>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </section>

</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const slides = document.querySelectorAll('.hc-hero-bg');
        const dots = document.querySelectorAll('.hc-dot');
        const prevBtn = document.getElementById('prevSlideBtn');
        const nextBtn = document.getElementById('nextSlideBtn');
        
        let currentSlide = 0;
        const totalSlides = slides.length;
        const slideIntervalTime = 5000; // Changes image automatically every 5 seconds
        let slideInterval;

        function updateSliderProgress(index) {
            // Remove active tags everywhere
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));

            // Set new active element state
            slides[index].classList.add('active');
            dots[index].classList.add('active');
            currentSlide = index;
        }

        function nextSlide() {
            let next = (currentSlide + 1) >= totalSlides ? 0 : currentSlide + 1;
            updateSliderProgress(next);
        }

        function prevSlide() {
            let prev = (currentSlide - 1) < 0 ? totalSlides - 1 : currentSlide - 1;
            updateSliderProgress(prev);
        }

        // Run automatic rotating cycle loop
        function startAutoRotation() {
            slideInterval = setInterval(nextSlide, slideIntervalTime);
        }

        // Reset the interval timer upon manual button click events
        function resetAutoRotation() {
            clearInterval(slideInterval);
            startAutoRotation();
        }

        // Event Listeners for controls
        nextBtn.addEventListener('click', function(e) {
            e.preventDefault();
            nextSlide();
            resetAutoRotation();
        });

        prevBtn.addEventListener('click', function(e) {
            e.preventDefault();
            prevSlide();
            resetAutoRotation();
        });

        dots.forEach(dot => {
            dot.addEventListener('click', function() {
                const targetSlide = parseInt(this.getAttribute('data-slide'));
                updateSliderProgress(targetSlide);
                resetAutoRotation();
            });
        });

        // Initialize background rotation process 
        startAutoRotation();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/welcome.blade.php ENDPATH**/ ?>