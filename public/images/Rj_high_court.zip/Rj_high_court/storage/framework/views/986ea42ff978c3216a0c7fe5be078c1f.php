<footer class="bg-navy text-white-50 pt-5 pb-3 border-top border-warning border-4">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4 col-lg-3">
                <h5 class="text-white mb-3 fw-bold border-bottom border-secondary pb-2">Apex Portals</h5>
                <ul class="list-unstyled lh-lg small">
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> Supreme Court of India</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> The President of India</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> Prime Minister of India</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> Government of India</a></li>
                </ul>
            </div>

            <div class="col-md-4 col-lg-3">
                <h5 class="text-white mb-3 fw-bold border-bottom border-secondary pb-2">State Links</h5>
                <ul class="list-unstyled lh-lg small">
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> Government of Rajasthan</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> Legislative Assembly</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> District Courts of Rajasthan</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> State Legal Services Auth.</a></li>
                </ul>
            </div>

            <div class="col-md-4 col-lg-3">
                <h5 class="text-white mb-3 fw-bold border-bottom border-secondary pb-2">Academies</h5>
                <ul class="list-unstyled lh-lg small">
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> National Judicial Academy</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> State Judicial Academy</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none hover-white"><i class="fa-solid fa-angle-right me-1"></i> Screen Reader Access Profile</a></li>
                </ul>
            </div>

            <div class="col-lg-3">
                <h5 class="text-white mb-3 fw-bold border-bottom border-secondary pb-2">Get In Touch</h5>
                <div class="mb-3">
                    <div class="fw-bold text-gold small"><i class="fa-solid fa-location-dot me-1"></i> Jodhpur Seat (Principal)</div>
                    <p class="mb-0 small text-light">Helpline: 9414056204<br>Email: hc-rj[at]nic[dot]in</p>
                </div>
                <div>
                    <div class="fw-bold text-gold small"><i class="fa-solid fa-location-dot me-1"></i> Jaipur Bench</div>
                    <p class="mb-0 small text-light">Helpline: 7023103127<br>Email: hcjaipur-rj[at]nic[dot]in</p>
                </div>
            </div>
        </div>

        <hr class="border-secondary my-4">

        <div class="row align-items-center small">
            <div class="col-md-6 text-center text-md-start">
                &copy; <?php echo e(date('Y')); ?> Rajasthan High Court. All Rights Reserved.
            </div>
            <div class="col-md-6 text-center text-md-end text-white-50">
                Designed & Maintained by <span class="text-white font-monospace">National Informatics Centre (NIC)</span>
            </div>
        </div>
    </div>
</footer>

<style>
    .hover-white:hover {
        color: #fff !important;
        padding-left: 4px;
        transition: all 0.2s ease-in-out;
    }
</style><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/website/layouts/partials/footer.blade.php ENDPATH**/ ?>