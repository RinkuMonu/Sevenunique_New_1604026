<div class="top-bar">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <span class="me-3"><i class="fa-solid fa-calendar-days text-warning"></i> <?php echo e(date('l, F d, Y')); ?></span>
        </div>
        <div>
            <a href="#">A-</a> <a href="#" class="bg-secondary px-1">A</a> <a href="#">A+</a>
            <a href="#" class="ms-3 border px-1 border-light">हिन्दी</a>
        </div>
    </div>
</div>

<header class="py-3 bg-white border-bottom shadow-sm">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <i class="fa-solid fa-building-columns fa-3x text-secondary me-3"></i>
            <div>
                <h1 class="h4 fw-bold m-0" style="color: var(--primary-blue);">Rajasthan High Court</h1>
                <p class="small text-muted fw-semibold m-0">(राजस्थान उच्च न्यायालय)</p>
            </div>
        </div>
        <div class="text-end d-none d-md-block">
            <i class="fa-solid fa-gavel fa-2x" style="color: var(--gold-accent);"></i>
        </div>
    </div>
</header>

<nav class="navbar navbar-expand-lg navbar-dark shadow-sm" style="background-color: var(--primary-blue); padding: 0.2rem 1rem;">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#hcNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="hcNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 navbar-nav-scroll" style="font-size: 14px; fw-bold;">
                <li class="nav-item border-end border-secondary"><a class="nav-link active bg-dark px-3 text-white" href="#"><i class="fa-solid fa-house"></i> Home</a></li>
                <li class="nav-item dropdown border-end border-secondary">
                    <a class="nav-link dropdown-toggle text-white px-3" href="#" data-bs-toggle="dropdown">Menu</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">About Court</a></li>
                        <li><a class="dropdown-item" href="#">History</a></li>
                    </ul>
                </li>
                <li class="nav-item border-end border-secondary"><a class="nav-link text-white px-3" href="#">Cause List</a></li>
                <li class="nav-item dropdown border-end border-secondary">
                    <a class="nav-link dropdown-toggle text-white px-3" href="#" data-bs-toggle="dropdown">Case Status</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">By Case Number</a></li>
                        <li><a class="dropdown-item" href="#">By Party Name</a></li>
                    </ul>
                </li>
                <li class="nav-item border-end border-secondary"><a class="nav-link text-white px-3" href="#">Judgments</a></li>
                <li class="nav-item border-end border-secondary"><a class="nav-link text-white px-3" href="#">Latest Updates</a></li>
                <li class="nav-item dropdown border-end border-secondary">
                    <a class="nav-link dropdown-toggle text-white px-3" href="#" data-bs-toggle="dropdown">e-Services</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">e-Filing</a></li>
                        <li><a class="dropdown-item" href="#">Virtual Courts</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link text-white px-3" href="#">Commercial Courts</a></li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\Rj_high_court\resources\views/website/layout/partials/header.blade.php ENDPATH**/ ?>