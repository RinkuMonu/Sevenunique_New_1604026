<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
|--------------------------------------------------------------------------
| High Court of Rajasthan - Web Routes
|--------------------------------------------------------------------------
|
| Version 1: Modern Natural Design  → /
| Version 2: SCI Inspired Design    → /v2
|
*/
 
// Version 1 - Modern Natural Home
Route::get('/v1', function () {
    return view('welcome');
})->name('home');
 
// Version 2 - SCI Inspired Home
Route::get('/v2', function () {
    return view('pages.home-v2');
})->name('home.v2');
 
// Switch between versions
Route::get('/design-v1', function () {
    return redirect('/');
});
 
Route::get('/design-v2', function () {
    return redirect('/v2');
});

Route::get('/history' , function ()  {
   return view('history'); 
})->name('history');

Route::get('/registrar-general' , function () {
return view('registrar');
})->name('registrar');