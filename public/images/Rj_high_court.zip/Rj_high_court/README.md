// have to add the features - landing page
1. hindi english
2. font ++ --
3. hero image - resposive 
4. ome scroll btn jo ki page ke end me le jaye