<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<style>
    :root {
        --hc-primary: #002b66;
        --hc-accent: #f1b24a;
        --hc-bg-footer: #ffffff; /* इमेज के अनुसार बैकग्राउंड सफ़ेद किया */
        --hc-card-bg: #ffffff;
        --hc-text-main: #334155;
        --hc-text-muted: #64748b;
        --hc-border-light: #f1f5f9;
        
        /* ब्रांड गाइडलिन कलर्स (इमेज के अनुसार) */
        --icon-blue: #0284c7;
        --icon-orange: #f97316;
        --icon-green: #22c55e;
    }

    /* --- MAIN FOOTER CONTENT --- */
    .hc-main-footer {
        background-color: var(--hc-bg-footer);
        padding: 60px 40px 30px 40px;
        border-top: 1px solid #e2e8f0;
    }
    
    .hc-footer-card {
        background: var(--hc-card-bg);
        border-radius: 20px; /* इमेज की तरह ज़्यादा राउंडेड कॉर्नर्स */
        padding: 30px;
        height: 100%;
        box-shadow: 0 10px 30px rgba(0, 43, 102, 0.03); /* प्रीमियम सॉफ्ट शैडो इफ़ेक्ट */
        border: 1px solid #f1f5f9;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    /* कार्ड होवर इफ़ेक्ट */
    .hc-footer-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 15px 35px rgba(0, 43, 102, 0.06);
    }

    .hc-footer-card h5 {
        font-size: 16px;
        font-weight: 700;
        color: var(--hc-primary);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    /* अलग-अलग सेक्शन्स के आइकन्स के लिए कलरफुल ग्लो इफ़ेक्ट */
    .card-title-links i { color: var(--icon-blue); }
    .card-title-committee i { color: var(--icon-orange); }
    .card-title-contact i { color: var(--icon-green); }

    /* Links Formatting */
    .hc-footer-links {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .hc-footer-links li {
        margin-bottom: 0;
        border-bottom: 1px solid #f8fafc;
        padding: 10px 0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .hc-footer-links li:first-child { padding-top: 0; }
    .hc-footer-links li:last-child { border-bottom: none; padding-bottom: 0; }
    
    .hc-footer-links a {
        color: var(--hc-text-main);
        text-decoration: none;
        font-size: 13.5px;
        font-weight: 500;
        transition: all 0.25s ease;
    }
    
    /* लिंक होवर इफ़ेक्ट */
    .hc-footer-links a:hover {
        color: var(--icon-blue);
        padding-left: 6px;
    }
    
    .hc-arrow-icon {
        font-size: 10px;
        color: #cbd5e1;
        transition: transform 0.25s;
    }
    .hc-footer-links li:hover .hc-arrow-icon {
        color: var(--icon-blue);
        transform: translateX(3px);
    }

    /* Contact Row Styling */
    .hc-contact-row {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 12px 0;
        border-bottom: 1px solid #f8fafc;
    }
    .hc-contact-row:first-child { padding-top: 0; }
    .hc-contact-row:last-child { border-bottom: none; padding-bottom: 0; }

    .hc-icon-box {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        flex-shrink: 0;
        transition: transform 0.2s;
    }
    .hc-contact-row:hover .hc-icon-box {
        transform: scale(1.1);
    }
    
    /* सुंदर कलर पैलेट */
    .bg-green-light { background: #f0fdf4; color: #16a34a; }
    .bg-blue-light { background: #f0f9ff; color: #0284c7; }
    .bg-red-light  { background: #fef2f2; color: #dc2626; }
    
    .hc-contact-text p {
        margin: 0;
        font-size: 13.5px;
        color: var(--hc-text-main);
        font-weight: 600;
    }
    .hc-contact-text span {
        font-size: 12px;
        color: var(--hc-text-muted);
        display: block;
        margin-top: 2px;
    }

    /* बटन इफ़ेक्ट */
    .hc-btn-more {
        font-size: 12.5px;
        font-weight: 600;
        color: var(--hc-primary);
        text-decoration: none;
        border: 1px solid #e2e8f0;
        padding: 6px 16px;
        border-radius: 20px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-top: 20px;
        transition: all 0.2s ease;
        background: #f8fafc;
    }
    .hc-btn-more:hover {
        background: var(--hc-primary);
        color: #ffffff !important;
        border-color: var(--hc-primary);
    }

    /* --- BOTTOM STRIP & COUNTER --- */
    .hc-bottom-strip {
        background: #f8fafc; /* नीचे की पट्टी को हल्का सा अलग बैकग्राउंड दिया */
        padding: 24px 40px;
        border-top: 1px solid #e2e8f0;
        font-size: 13px;
        color: var(--hc-text-muted);
    }
    .hc-bottom-strip a {
        color: var(--hc-primary);
        text-decoration: none;
        font-weight: 600;
    }
    .hc-bottom-strip a:hover { text-decoration: underline; }

    /* मॉडर्न डिजिटल काउंटर */
    .hc-counter-wrapper {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
    }
    .hc-digit {
        background: #ffffff;
        color: var(--hc-primary);
        padding: 4px 8px;
        border-radius: 6px;
        font-family: 'Courier New', Courier, monospace;
        font-weight: 700;
        font-size: 14px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 2px 4px rgba(0,0,0,0.02);
    }
</style>

<footer class="hc-main-footer">
    <div class="row g-4">
        
        <div class="col-lg-4 col-md-6">
            <div class="hc-footer-card d-flex flex-column justify-content-between">
                <div>
                    <h5 class="card-title-links"><i class="fa-solid fa-link"></i> Important Links</h5>
                    <ul class="hc-footer-links">
                        <li><a href="#">The President of India</a> <i class="fa-solid fa-chevron-right hc-arrow-icon"></i></li>
                        <li><a href="#">Prime Minister of India</a> <i class="fa-solid fa-chevron-right hc-arrow-icon"></i></li>
                        <li><a href="#">Supreme Court of India</a> <i class="fa-solid fa-chevron-right hc-arrow-icon"></i></li>
                        <li><a href="#">e-Committee, Supreme Court of India</a> <i class="fa-solid fa-chevron-right hc-arrow-icon"></i></li>
                        <li><a href="#">Indian Parliament</a> <i class="fa-solid fa-chevron-right hc-arrow-icon"></i></li>
                        <li><a href="#">Central Acts and Rules</a> <i class="fa-solid fa-chevron-right hc-arrow-icon"></i></li>
                    </ul>
                </div>
                <div>
                    <a href="#" class="hc-btn-more">View All Links <i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6">
            <div class="hc-footer-card d-flex flex-column justify-content-between">
                <div>
                    <h5 class="card-title-committee"><i class="fa-solid fa-users"></i> Supreme Court Legal Services Committee</h5>
                    <div class="row">
                        <div class="col-6">
                            <ul class="hc-footer-links">
                                <li><a href="#">Indian Courts</a></li>
                                <li><a href="#">Government Of India</a></li>
                                <li><a href="#">Government Of Rajasthan</a></li>
                                <li><a href="#">Rajasthan Legislative Assembly</a></li>
                                <li><a href="#">National Legal Services Authority</a></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="hc-footer-links">
                                <li><a href="#">National Judicial Academy</a></li>
                                <li><a href="#">State Judicial Academy</a></li>
                                <li><a href="#">District Courts</a></li>
                                <li><a href="#">Screen Reader Access</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div>
                    <a href="#" class="hc-btn-more">More Resources <i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-12">
            <div class="hc-footer-card d-flex flex-column justify-content-between">
                <div>
                    <h5 class="card-title-contact"><i class="fa-solid fa-location-dot"></i> Get In Touch</h5>
                    
                    <div class="hc-contact-row">
                        <div class="hc-icon-box bg-green-light">
                            <i class="fa-solid fa-building-columns"></i>
                        </div>
                        <div class="hc-contact-text">
                            <p>Rajasthan High Court Principal Seat, Jodhpur</p>
                            <span>Jodhpur, Rajasthan</span>
                        </div>
                    </div>

                    <div class="hc-contact-row">
                        <div class="hc-icon-box bg-blue-light">
                            <i class="fa-solid fa-headset"></i>
                        </div>
                        <div class="hc-contact-text">
                            <p>e-Services Helpline: 9414056244</p>
                            <span>(for litigant-in-person)</span>
                        </div>
                    </div>

                    <div class="hc-contact-row">
                        <div class="hc-icon-box bg-red-light">
                            <i class="fa-solid fa-map-location-dot"></i>
                        </div>
                        <div class="hc-contact-text">
                            <p>Rajasthan High Court Bench, Jaipur</p>
                            <span style="color: #64748b; font-weight: 500;">Helpline: 7023103127 | 0141-2227764</span>
                        </div>
                    </div>
                </div>
                <div>
                    <a href="#" class="hc-btn-more">View Contact Details <i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
        </div>

    </div>
</footer>

<div class="hc-bottom-strip">
    <div class="row align-items-center">
        <div class="col-lg-8 col-12 text-center text-lg-start mb-3 mb-lg-0">
            <div class="mb-2">
                <i class="fa-solid fa-code text-muted me-1"></i> Site Developed and Hosted by <a href="https://www.nic.in/" target="_blank">National Informatics Centre</a>
            </div>
            <div>
                <i class="fa-solid fa-circle-copyright text-muted me-1"></i> Content owned, maintained and updated by <strong>Rajasthan High Court</strong> © 2026
            </div>
        </div>
        
        <div class="col-lg-4 col-12 hc-counter-wrapper text-center">
            <span class="me-2 fw-semibold text-secondary" style="font-size: 13.5px;">Total Hits:</span>
            <div class="d-inline-flex gap-1">
                <span class="hc-digit">0</span>
                <span class="hc-digit">1</span>
                <span class="hc-digit">2</span>
                <span class="hc-digit">3</span>
                <span class="hc-digit">4</span>
                <span class="hc-digit">5</span>
                <span class="hc-digit">6</span>
                <span class="hc-digit">7</span>
                <span class="hc-digit">8</span>
                <span class="hc-digit">9</span>
            </div>
        </div>
    </div>
</div>