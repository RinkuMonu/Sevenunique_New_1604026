<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <title>@yield('title', 'Rajasthan High Court')</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1; 
        }

        /* Responsive wrapper adjustments for sidebar architecture */
        .hc-main-layout-wrapper {
            padding: 30px 0;
        }
    </style>
    
    @yield('styles') 
</head>
<body>

    {{-- Header --}}
    @include('layouts.partials.header-v1')

    {{-- Main Working Template Segment --}}
    <main>
        <div class="container-fluid px-2 px-md-5 hc-main-layout-wrapper">
            <div class="row g-4">
                
                <div class="col-12 col-lg-3 col-xl-3">
                    @include('layouts.partials.sidebar-v1')
                </div>

                <div class="col-12 col-lg-9 col-xl-9">
                    @yield('content')
                </div>

            </div>
        </div>
    </main>

    {{-- Footer --}}
    @include('layouts.partials.footer-v1')


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    @yield('scripts')
</body>
</html>